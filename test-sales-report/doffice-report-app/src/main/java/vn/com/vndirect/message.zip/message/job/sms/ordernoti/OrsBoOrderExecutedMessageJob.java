package vn.com.vndirect.message.job.sms.ordernoti;

import com.homedirect.common.solr.repository.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.order.OrsBoOrderExecutedEvent;
import vn.com.vndirect.event.transaction.service.OrsBoOrderExecutedEventService;
import vn.com.vndirect.message.job.sms.SendSmsJob;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

// Khối lệnh cơ sở

/*
 * VNDIRECT KQGD: dd/mm/yyyy hh:mm xxxxxxxxxx # Mua yyyyyy ABC gia zzz,zzz d Khop yyyyyy gia zzz,zzz d.
 */

@Service
public class OrsBoOrderExecutedMessageJob extends SendSmsJob<OrsBoOrderExecutedEvent> {

    public final static Logger logger = LoggerFactory.getLogger(OrsBoOrderExecutedMessageJob.class);

    @Autowired
    public OrsBoOrderExecutedMessageJob(@Value("${event.message-job.enabled:true}") Boolean enabled
            , OrsBoOrderExecutedEventService service) {
        super(service, 20, 10, enabled);
    }

    @Override
    public List<SMSRequest> createMessages(OrsBoOrderExecutedEvent event) throws Exception {
        SMSRequest sms = createSmsRequest();

        sms.setTemplate("sms_ors_bo");
        sms.setSubject("ORD");
        sms.setModule("BO");

        Map<String, Object> fields = new HashMap<>();
        List<SMSRequest> list = new ArrayList<SMSRequest>(1);

        if (!("Filled".equals(event.getStatus()) || "PartiallyFilled".equals(event.getStatus()))) {
            return Collections.emptyList();
        }

        if (!("NB".equals(event.getSide()) || "NS".equals(event.getSide()))) {
            return Collections.emptyList();
        }

        Long timestampMiliStr = Long.parseLong(event.getPlacedTime());
        Date placeDate = new Date(timestampMiliStr);
        String valueDate = new SimpleDateFormat("dd/MM/yyyy").format(placeDate);
        String valueTime = new SimpleDateFormat("HH:mm:ss").format(placeDate);

        fields.put("value_date", valueDate);
        fields.put("value_time", valueTime);

        fields.put("account_no", event.getAccountNo());
        fields.put("side", event.getSide());
        fields.put("symbol", event.getSymbol());

        String price = event.getPrice();
        String executedPrice = event.getExecutedPrice();
        Locale localeEN = new Locale("en", "EN");
        NumberFormat en = NumberFormat.getInstance(localeEN);
        String priceFm = en.format(Double.parseDouble(price));
        String executedPriceFm = en.format(Double.parseDouble(executedPrice));

        fields.put("price", priceFm);
        fields.put("executed_price", executedPriceFm);

        fields.put("quantity", en.format(Integer.parseInt(event.getQuantity())));
        fields.put("executed_quantity", en.format(Integer.parseInt(event.getExecutedQuantity())));

        sms.setTempFields(fields);
        list.add(sms);

        list.forEach(smsRequest -> {
            //   for test
           /* smsRequest.setReceiverId(123456789l);
            smsRequest.setReceiverName("john");
            smsRequest.setAccountNo(event.getAccountNo());
            smsRequest.setReceiverPhone("0959565896");*/

            try {
                loadReceiver(smsRequest, event);
            } catch (RepositoryException e) {
                logger.error("Load receiver phone order event error for account :" + event.getAccountNo());
            }
        });

        if (!validateSmsTemplate(list)) {
            logger.error("Order Message Mapper: No template or message content for sms");
            return Collections.emptyList();
        }

        if (!validateSmsReceiver(list)) {
            logger.error("Order Message Mapper: No receiver or message content for sms");
            return Collections.emptyList();
        }

        return list;
    }

    protected SMSRequest createSmsRequest() {
        SMSRequest newSms = new SMSRequest();
        newSms.setBrandName("VNDS");
        newSms.setProvider("vndirect");
        newSms.setService("sms");

        return newSms;
    }

    public void loadReceiver(SMSRequest sms, OrsBoOrderExecutedEvent event) throws RepositoryException {
        sms.setAccountNo(event.getAccountNo());
        // TODO
        sms.setReceiverPhone(event.getAccountNo());
        // loadReceiverByAccountNo(sms, event.getAccountNo());
    }

    private boolean validateSmsReceiver(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getReceiverId()) && StringUtils.isEmpty(sms.getReceiverPhone())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getMessage()) && StringUtils.isEmpty(sms.getTemplate())) return false;
        }
        return true;
    }
}
