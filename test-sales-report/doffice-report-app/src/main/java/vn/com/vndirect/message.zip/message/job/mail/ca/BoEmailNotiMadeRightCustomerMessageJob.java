package vn.com.vndirect.message.job.mail.ca;

// Thông báo Quyền Mua cổ phiếu phát hành thêm

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.ca.service.BoEmailNotiMadeRightCustomerService;
import vn.com.vndirect.event.model.ca.BoNotiMadeRightCustomerEvent;
import vn.com.vndirect.message.job.mail.SendEmailJob;

import java.text.SimpleDateFormat;
import java.util.*;

// Email thông báo Quyền được thực hiện cho Khách hàng

//@Service
public class BoEmailNotiMadeRightCustomerMessageJob extends SendEmailJob<BoNotiMadeRightCustomerEvent> {

    public static final Logger LOGGER = LoggerFactory.getLogger(BoEmailNotiMadeRightCustomerMessageJob.class);
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    public BoEmailNotiMadeRightCustomerMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                                  BoEmailNotiMadeRightCustomerService service) {
        super(service, enabled);
    }

    @Override
    public List<EmailRequest> createMessages(BoNotiMadeRightCustomerEvent event) throws Exception {

        EmailRequest email = new EmailRequest();

        StringBuilder subject = new StringBuilder("Thông báo Quyền được thực hiện cho Khách hàng tài khoản số ");
        subject.append(event.getAccountNo());

        email.setSubject(subject.toString());

        email.setTemplate("email_noti_made_right_customer_ca");

        email.setModule("BO");
        email.setService("mail_elastic");

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(1);

        BoNotiMadeRightCustomerEvent.BoEmailNotiMadeRightCustomerAgg[] dataAggs = event.getDataAggs();
        if (dataAggs == null || dataAggs.length == 0) return Collections.emptyList();

        fields.put("customer_name", event.getFullNameCust());
        fields.put("account_no", event.getAccountNo());
        fields.put("tx_date", dataAggs[0].getTxDate());
        fields.put("table", mapper.writeValueAsString(dataAggs));

        email.setTempfields(fields);
        email.setReceiver(event.getEmail());
        // TODO: test
        email.setReceiver("phongnhatran2893@gmail.com");
        list.add(email);

        if (!validateEmailTemplate(list)) {
            LOGGER.error("Email Noti Made Right Customer: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            LOGGER.error("Email Noti Made Right Customer: No receiver or subject for email");
            return Collections.emptyList();
        }

        return list;

    }


    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateEmailTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }
}
