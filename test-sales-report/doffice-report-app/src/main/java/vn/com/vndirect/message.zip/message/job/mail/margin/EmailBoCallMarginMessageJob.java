package vn.com.vndirect.message.job.mail.margin;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.margin.service.BoCallMarginService;
import vn.com.vndirect.event.model.margin.BoCallMarginEvent;
import vn.com.vndirect.message.job.mail.SendEmailJob;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

// Thông báo Nợ đến hạn cơ sở  - Email
// @Service
public class EmailBoCallMarginMessageJob extends SendEmailJob<BoCallMarginEvent> {

    public static final Logger logger = LoggerFactory.getLogger(EmailBoCallMarginMessageJob.class);

    public static final SimpleDateFormat DB_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public EmailBoCallMarginMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                       BoCallMarginService service) {
        super(service, enabled);
    }

    @Override
    public List<EmailRequest> createMessages(BoCallMarginEvent event) throws ParseException {
        EmailRequest emailBroker = new EmailRequest();
        EmailRequest emailManager = new EmailRequest();

        emailBroker.setModule("BO");
        emailBroker.setService("mail_elastic");
        emailBroker.setAccountNo(event.getAccountNo());

        emailManager.setModule("BO");
        emailManager.setService("mail_elastic");
        emailManager.setAccountNo(event.getAccountNo());

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(2);

        if (StringUtils.isEmpty(event.getCustomerFullName()) || StringUtils.isEmpty(event.getFullNameManager())
                || StringUtils.isEmpty(event.getFullNameBroker()) || StringUtils.isEmpty(event.getGroupName())) return Collections.emptyList();

        fields.put("full_name", event.getFullNameBroker());
        fields.put("prin_period", DATE_FORMAT.format(DB_FORMAT.parse(event.getPrinPeriod())));

        fields.put("ac_type", event.getAfType());
        fields.put("acct_no", event.getAccountNo());
        fields.put("full_name_cust", event.getCustomerFullName());

        switch (event.getCategory()) {
            case "MARGIN LOAN":
                fields.put("prin_ovd_total", formatNumber(event.getPrinOvd()));
                fields.put("prin_ovd_mr", formatNumber(event.getPrinOvd()));
                fields.put("prin_ovd_df_sl", "0");
                fields.put("prin_ovd_tplus", "0");

                fields.put("prin_due_total", formatNumber(event.getPrinDue()));
                fields.put("prin_due_mr", formatNumber(event.getPrinDue()));
                fields.put("prin_due_df_sl", "0");
                fields.put("prin_due_tplus", "0");

                fields.put("prin_tom_total", formatNumber(StringUtils.isEmpty(event.getPrinDueTomor()) ? "0" : event.getPrinDueTomor()));
                fields.put("prin_tom_mr", formatNumber(StringUtils.isEmpty(event.getPrinDueTomor()) ? "0" : event.getPrinDueTomor()));
                fields.put("prin_tom_df_sl", "0");
                fields.put("prin_tom_tplus", "0");

                fields.put("prin_week_total", formatNumber(StringUtils.isEmpty(event.getPrinDueWeek()) ? "0" : event.getPrinDueWeek()));
                fields.put("prin_week_mr", formatNumber(StringUtils.isEmpty(event.getPrinDueWeek()) ? "0" : event.getPrinDueWeek()));
                fields.put("prin_week_df_sl", "0");
                break;
            case "DF LOAN":
            case "SL LOAN":
                fields.put("prin_ovd_total", formatNumber(event.getPrinOvd()));
                fields.put("prin_ovd_mr", "0");
                fields.put("prin_ovd_df_sl", formatNumber(event.getPrinOvd()));
                fields.put("prin_ovd_tplus", "0");

                fields.put("prin_due_total", formatNumber(event.getPrinDue()));
                fields.put("prin_due_mr", "0");
                fields.put("prin_due_df_sl", formatNumber(event.getPrinDue()));
                fields.put("prin_due_tplus", "0");

                fields.put("prin_tom_total", formatNumber(StringUtils.isEmpty(event.getPrinDueTomor()) ? "0" : event.getPrinDueTomor()));
                fields.put("prin_tom_mr", "0");
                fields.put("prin_tom_df_sl", formatNumber(StringUtils.isEmpty(event.getPrinDueTomor()) ? "0" : event.getPrinDueTomor()));
                fields.put("prin_tom_tplus", "0");

                fields.put("prin_week_total", formatNumber(StringUtils.isEmpty(event.getPrinDueWeek()) ? "0" : event.getPrinDueWeek()));
                fields.put("prin_week_mr", "0");
                fields.put("prin_week_df_sl", formatNumber(StringUtils.isEmpty(event.getPrinDueWeek()) ? "0" : event.getPrinDueWeek()));
                break;
            case "T0 LOAN":
            case "TPLUS":
                fields.put("prin_ovd_total", formatNumber(event.getPrinOvd()));
                fields.put("prin_ovd_mr", "0");
                fields.put("prin_ovd_df_sl", "0");
                fields.put("prin_ovd_tplus", formatNumber(event.getPrinOvd()));

                fields.put("prin_due_total", formatNumber(event.getPrinDue()));
                fields.put("prin_due_mr", "0");
                fields.put("prin_due_df_sl", "0");
                fields.put("prin_due_tplus", formatNumber(event.getPrinDue()));

                fields.put("prin_tom_total", formatNumber(StringUtils.isEmpty(event.getPrinDueTomor()) ? "0" : event.getPrinDueTomor()));
                fields.put("prin_tom_mr", "0");
                fields.put("prin_tom_df_sl", "0");
                fields.put("prin_tom_tplus", formatNumber(StringUtils.isEmpty(event.getPrinDueTomor()) ? "0" : event.getPrinDueTomor()));

                fields.put("prin_week_total", formatNumber(StringUtils.isEmpty(event.getPrinDueWeek()) ? "0" : event.getPrinDueWeek()));
                fields.put("prin_week_mr", "0");
                fields.put("prin_week_df_sl", "0");
                break;
            default:
        }
        emailBroker = createMessagesForBroker(event, emailBroker, fields);
        list.add(emailBroker);

        emailManager = createMessagesForManager(event, emailManager, fields);
        list.add(emailManager);

        if (!validateEmailTemplate(list)) {
            logger.error("Email Bo Call Margin Message Mapper: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            logger.error("Email Bo Call Margin Message Mapper: No receiver or subject for email");
            return Collections.emptyList();
        }
        return list;
    }

    private EmailRequest createMessagesForBroker(BoCallMarginEvent event, EmailRequest email, Map<String, Object> fields) {
        email.setTempfields(fields);
        email.setTemplate("email_bo_call_margin_brokers");
        String emailBroker = event.getUserNameBroker() + "@vndirect.com.vn";
        email.setReceiver(emailBroker);
        email.setSubject("Thông báo Call Margin giao dịch cơ sở - Môi giới");

        // TODO: fake
        email.setReceiver("tuanhaminh89@gmail.com");

        return email;
    }

    private EmailRequest createMessagesForManager(BoCallMarginEvent event, EmailRequest email, Map<String, Object> fields) {
        Map<String, Object> managerFields = new HashMap<>(fields);
        managerFields.put("manager_full_name", event.getFullNameManager());
        managerFields.put("group_name", event.getGroupName());

        email.setTempfields(managerFields);

        email.setTemplate("email_bo_call_margin_manager_brokers");
        String emailManager = event.getUserNameManager() + "@vndirect.com.vn";
        email.setReceiver(emailManager);
        email.setSubject("Thông báo Call Margin giao dịch cơ sở - Trưởng phòng");

        // TODO: fake
        email.setReceiver("tuanhaminh89@gmail.com");
        return email;
    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateEmailTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }

    public String formatNumber(String number) {
        Locale localeEN = new Locale("en", "EN");
        NumberFormat numberFormat = NumberFormat.getInstance(localeEN);
        String numberFM = numberFormat.format(Long.parseLong(number));
        return numberFM;
    }
}
