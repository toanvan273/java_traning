package vn.com.vndirect.message.job.mail.other;

// Email: Single Stock Saving thông báo nhắc lịch nộp tiền cho KH sử dụng sản phẩm

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.model.other.BoSSSRemindPaymentScheduleEvent;
import vn.com.vndirect.event.other.BoSSSRemindPaymentScheduleService;
import vn.com.vndirect.message.job.mail.SendEmailJob;

import java.text.SimpleDateFormat;
import java.util.*;

//@Service
public class BoEmailSSSRemindPaymentScheduleMessageJob extends SendEmailJob<BoSSSRemindPaymentScheduleEvent> {

    public static final Logger LOGGER = LoggerFactory.getLogger(BoEmailSSSRemindPaymentScheduleMessageJob.class);
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public BoEmailSSSRemindPaymentScheduleMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                                     BoSSSRemindPaymentScheduleService service) {
        super(service, enabled);
    }

    @Override
    public List<EmailRequest> createMessages(BoSSSRemindPaymentScheduleEvent event) throws Exception {

        EmailRequest email = new EmailRequest();
        String subject;
        if (BoSSSRemindPaymentScheduleEvent.FIRST_TIME_REMIND.equals(event.getRemindType())) {
            subject = "Nhắc lịch nộp tiền chương trình Tiết kiệm đầu tư cổ phiếu định kỳ (Single Stock Saving)";
        } else {
            subject = "Thông báo nhắc lịch nộp tiền chương trình Tiết kiệm đầu tư cổ phiếu định kỳ (lần 2)";
        }

        email.setSubject(subject);
        email.setTemplate("email_single_stock_saving_for_client");

        email.setModule("BO");
        email.setService("mail_elastic");

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(1);

        fields.put("customer_name", event.getFullNameCust());
        fields.put("symbol", event.getSymbol());
        fields.put("contract_no", event.getContractNo());
        email.setReceiver(event.getEmail());
        email.setReceiver("phongnhatran2893@gmail.com"); // test
        list.add(email);

        if (!validateEmailTemplate(list)) {
            LOGGER.error("Email SSS Remind Payment Schedule Message Mapper: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            LOGGER.error("Email SSS Remind Payment Schedule Message Mapper: No receiver or subject for email");
            return Collections.emptyList();
        }

        return list;

    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateEmailTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }
}
