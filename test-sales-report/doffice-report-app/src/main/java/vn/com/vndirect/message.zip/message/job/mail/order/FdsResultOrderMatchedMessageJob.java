package vn.com.vndirect.message.job.mail.order;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.homedirect.common.solr.repository.RepositoryException;

import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.model.order.call.result.FdsResultOrderMatchedEvent;
import vn.com.vndirect.event.order.call.result.FdsResultOrderMatchedService;
import vn.com.vndirect.message.job.mail.SendEmailJob;


// Email: Thông báo kết quả khớp lệnh Phái Sinh (FDS)

// @Service
public class FdsResultOrderMatchedMessageJob extends SendEmailJob<FdsResultOrderMatchedEvent> {

    public static final Logger logger = LoggerFactory.getLogger(FdsResultOrderMatchedMessageJob.class);

    public static final SimpleDateFormat DATE_DB = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public FdsResultOrderMatchedMessageJob(@Value("${fds.message-job.enabled}") Boolean enabled,
                                           FdsResultOrderMatchedService service) {
        super(service, enabled);
    }

    @Autowired
    private ObjectMapper mapper;

    @Override
    public List<EmailRequest> createMessages(FdsResultOrderMatchedEvent event) throws Exception {
        EmailRequest email = new EmailRequest();

        Date txDate = DATE_DB.parse(event.getTxDate());

        StringBuilder subject = new StringBuilder("Kết quả khớp lệnh giao dịch Phái sinh tài khoản ");
        subject.append(event.getAccountNo()).append("P ngày ").append(DATE_FORMAT.format(txDate));

        email.setSubject(subject.toString());
        email.setTemplate("email_fds_result_order_matched_customer");
        email.setReceiver(event.getEmail());

        email.setModule("FDS");
        email.setService("mail_elastic");

        email.setAccountNo(event.getAccountNo());

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(1);

        FdsResultOrderMatchedEvent.FdsResultOrderMatchedAgg[] dataAggs = event.getFdsAggs();
        if (dataAggs == null || dataAggs.length == 0) return Collections.emptyList();

        fields.put("customer_name", event.getFullName());
        fields.put("tx_date", DATE_FORMAT.format(txDate));
        fields.put("account_no", event.getAccountNo());

        fields.put("table", mapper.writeValueAsString(dataAggs));
        email.setTempfields(fields);

        list.add(email);

        list.forEach(emailRequest -> {
            try {
                loadReceiver(emailRequest, event);
            } catch (RepositoryException e) {
                logger.error("Load receiver phone call Email Fds Order event error for account :" + event.getAccountNo());
            }
        });

        if (!validateSmsTemplate(list)) {
            logger.error("Email Fds Order Message Mapper: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            logger.error("Email Fds Order Message Mapper: No receiver or subject for email");
            return Collections.emptyList();
        }
        return list;
    }

    protected void loadReceiver(EmailRequest email, FdsResultOrderMatchedEvent event) throws RepositoryException {
        event.setEmail("ngoquangphucx5ql@gmail.com");
        if (!StringUtils.isEmpty(event.getEmail())) {
            email.setReceiver(event.getEmail());
            return;
        }
        if (!StringUtils.isEmpty(event.getCustId())) {
            loadReceiverByCustomerId(email, event.getCustId());
            return;
        }

        loadReceiverByAccountNo(email, event.getAccountNo());
    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }
}
