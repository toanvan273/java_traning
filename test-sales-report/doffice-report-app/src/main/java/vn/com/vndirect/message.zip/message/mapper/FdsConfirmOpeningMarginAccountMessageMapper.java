/***************************************************************************
 * Copyright 2019 by VNDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.message.mapper;

import java.util.Map;

import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.transaction.BodyEvent;
import vn.com.vndirect.event.model.transaction.TransactionChanged;
import vn.com.vndirect.message.job.sms.transaction.TransactionEventToMessageJob;

// Giao Dịch Mở TK

public class FdsConfirmOpeningMarginAccountMessageMapper extends TransactionToMessageMapper {

    public FdsConfirmOpeningMarginAccountMessageMapper(TransactionEventToMessageJob job) {
        super(job, "DC03");
    }

    @Override
    protected boolean addDataFieldFromChanged(Map<String, Object> fields, TransactionChanged changed) {
        return true;
    }

    @Override
    @SuppressWarnings("unused")
    protected void putDateTimeToField(Map<String, Object> fields, BodyEvent body) throws Exception {
    }

    @Override
    protected boolean isValidChanged(TransactionChanged changed) {
        return super.isValidEventType(changed, 'U');
    }

    @Override
    protected void setSmsMessageHeader(SMSRequest sms) {
        sms.setTemplate("sms_fds_confirm_opening_margin_account");
        sms.setSubject("FREE");
        sms.setModule("FDS");
    }

}
