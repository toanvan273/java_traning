package vn.com.vndirect.message.job.mail.margin;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.margin.service.BoCallMarginRttService;
import vn.com.vndirect.event.model.margin.BoCallMarginRttEvent;
import vn.com.vndirect.message.job.mail.SendEmailJob;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

// Thông báo tỷ lệ Rtt đối với tài sản cơ sở  - Email

// @Service
public class EmailBoCallMarginRttMessageJob extends SendEmailJob<BoCallMarginRttEvent> {

    public static final Logger logger = LoggerFactory.getLogger(EmailBoCallMarginRttMessageJob.class);

    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public EmailBoCallMarginRttMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                          BoCallMarginRttService service) {
        super(service, enabled);
    }

    @Override
    public List<EmailRequest> createMessages(BoCallMarginRttEvent event) throws Exception {
        EmailRequest emailBroker = new EmailRequest();
        EmailRequest emailManager = new EmailRequest();

        String date = DATE_FORMAT.format(new Date());

        emailBroker.setModule("BO");
        emailBroker.setService("mail_elastic");
        emailBroker.setAccountNo(event.getAccountNo());

        emailManager.setModule("BO");
        emailManager.setService("mail_elastic");
        emailManager.setAccountNo(event.getAccountNo());

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(2);

        if (StringUtils.isEmpty(event.getCustomerFullName()) || StringUtils.isEmpty(event.getFullNameManager())
                || StringUtils.isEmpty(event.getFullNameBroker()) || StringUtils.isEmpty(event.getGroupName()))
            return Collections.emptyList();

        fields.put("date_due", date);
        fields.put("deposit", event.getAfType());
        fields.put("acct_no", event.getAccountNo());

        fields.put("full_name_cust", event.getCustomerFullName());

        fields.put("race_margin", event.getAccRtt());
        fields.put("add_amt",formatNumber(event.getAddAmt()));
        fields.put("phone", event.getPhone());
        fields.put("delay_handle", "Not Handle");

        Map<String, Object> managerField = new HashMap<>(fields);

        emailBroker = createMessagesForBroker(event, emailBroker, fields);
        list.add(emailBroker);

        emailManager = createMessagesForManager(event, emailManager, managerField);
        list.add(emailManager);

        if (!validateEmailTemplate(list)) {
            logger.error("Email Bo Call Margin Message Mapper: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            logger.error("Email Bo Call Margin  Message Mapper: No receiver or subject for email");
            return Collections.emptyList();
        }
        return list;
    }

    private EmailRequest createMessagesForBroker(BoCallMarginRttEvent event, EmailRequest email, Map<String, Object> fields) {
        fields.put("broker_name", event.getFullNameBroker());
        email.setTempfields(fields);

        email.setTemplate("email_bo_call_margin_rtt_brokers");
        String emailBroker = event.getUserNameBroker() + "@vndirect.com.vn";
        email.setReceiver(emailBroker);
        email.setSubject("Thông báo Tỷ lệ RTT tài khoản cơ sở - Môi giới");

        // TODO: fake
        email.setReceiver("ngoquangphucx5ql@gmail.com");

        return email;
    }

    private EmailRequest createMessagesForManager(BoCallMarginRttEvent event, EmailRequest email, Map<String, Object> fields) {
        fields.put("manager_full_name", event.getFullNameManager());
        fields.put("group_name", event.getGroupName());

        logger.info("Field ....................." + fields);
        email.setTempfields(fields);

        String emailManager = event.getUserNameManager() + "@vndirect.com.vn";
        email.setReceiver(emailManager);
        email.setTemplate("email_bo_call_margin_rtt_manager_brokers");
        email.setSubject("Thông báo Tỷ lệ RTT tài khoản cơ sở - Trưởng phòng");

        // TODO: fake
        email.setReceiver("ngoquangphucx5ql@gmail.com");

        return email;
    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateEmailTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }

    public String formatNumber(String number) {
        Locale localeEN = new Locale("en", "EN");
        NumberFormat numberFormat = NumberFormat.getInstance(localeEN);
        String numberFM = numberFormat.format(Long.parseLong(number));
        return numberFM;
    }
}
