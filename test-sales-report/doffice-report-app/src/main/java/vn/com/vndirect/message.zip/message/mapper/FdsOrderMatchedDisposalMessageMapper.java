package vn.com.vndirect.message.mapper;

// Khớp lệnh phái sinh có xử lý

import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.transaction.TransactionChanged;
import vn.com.vndirect.message.job.sms.transaction.TransactionEventToMessageJob;

import java.util.Map;

public class FdsOrderMatchedDisposalMessageMapper extends TransactionToMessageMapper {
    public FdsOrderMatchedDisposalMessageMapper(TransactionEventToMessageJob job) {
        super(job, "DO30");
    }

    @Override
    protected boolean isValidChanged(TransactionChanged changed) {
        if (Integer.parseInt(changed.getMatchQuantity()) <= 0) return false;
        if (!"Y".equals(changed.getIsDisposal())) return false;
        return true;
    }

    @Override
    protected boolean addDataFieldFromChanged(Map<String, Object> fields, TransactionChanged changed) {
        fields.put("side", changed.getSide());
        fields.put("quantity", changed.getQuantity());
        fields.put("symbol", changed.getSymbol());
        fields.put("match_quantity", changed.getMatchQuantity());

        String price = changed.getPrice();
        String matchPrice = changed.getMatchPrice();

        String priceFm = numberFormat.format(Double.parseDouble(price));
        String matchPriceFm = numberFormat.format(Double.parseDouble(matchPrice));

        fields.put("price", priceFm);
        fields.put("match_price", matchPriceFm);

        return true;
    }

    @Override
    protected void setSmsMessageHeader(SMSRequest sms) {
        sms.setTemplate("sms_fds_order_matched_ydeposit");
        sms.setSubject("ORD");
        sms.setModule("FDS");
    }
}