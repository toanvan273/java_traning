package vn.com.vndirect.message.job.mail.other;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.model.other.BONotiBrokerAndManagerSalaryEvent;
import vn.com.vndirect.event.other.BoNotiBrokerAndManagerSalaryService;
import vn.com.vndirect.message.job.mail.SendEmailJob;

import java.text.SimpleDateFormat;
import java.util.*;

// Email: Thông báo Môi giới - Lương kinh doanh

//@Service
public class BoNotiBrokerAndBusinessSalaryMessageJob extends SendEmailJob<BONotiBrokerAndManagerSalaryEvent> {

    public static final Logger LOGGER = LoggerFactory.getLogger(BoNotiBrokerAndBusinessSalaryMessageJob.class);
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public BoNotiBrokerAndBusinessSalaryMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled, BoNotiBrokerAndManagerSalaryService service) {
        super(service, enabled);
    }

    @Override
    public List<EmailRequest> createMessages(BONotiBrokerAndManagerSalaryEvent event) throws Exception {
        EmailRequest email = new EmailRequest();

        String date = DATE_FORMAT.format(new Date());
        StringBuilder subject = new StringBuilder(" Thông báo chi tiết tính toán lương kinh doanh tới NVKD, trưởng phòng ");
//        subject.append("ngày ").append(date);

        email.setSubject(subject.toString());

        email.setTemplate("");

        email.setModule("BO");
        email.setService("mail_elastic");

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(2);

        fields.put("user_name", event.getUserNameBroker());
        fields.put("hr_code", event.getHrCode());

        email.setTempfields(fields);

        // email.setReceiver("phong.kdtt@vndirect.com.vn"); // const
        // email.setReceiver("ngoquangphucx5ql@gmail.com"); // test
        email.setReceiver("nguyentientho110@gmail.com"); // test

        list.add(email);


        if (!validateEmailTemplate(list)) {
            LOGGER.error("Email Bank Cash Deposit Message Mapper: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            LOGGER.error("Email  Bank Cash Deposit Message Mapper: No receiver or subject for email");
            return Collections.emptyList();
        }

        return list;
    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateEmailTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }
}
