package vn.com.vndirect.message.job.mail.order;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.model.order.confirm.NotiBrokerMissingOrderConfirmationEvent;
import vn.com.vndirect.event.order.confirm.NotiBrokerMissingOrderConfirmationService;
import vn.com.vndirect.message.job.mail.SendEmailJob;

// Email: Thông báo Khách hàng/Môi giới thiếu phiếu lệnh cơ sở (BO)
// Email: Thông báo Khách hàng/Môi giới thiếu phiếu lệnh Phái Sinh (FDS)
// For brocker
import java.text.SimpleDateFormat;
import java.util.*;

// Email: Thông báo Môi giới thiếu phiếu lệnh cơ sở (BO)
// Email: Thông báo Môi giới thiếu phiếu lệnh Phái Sinh (FDS)

// @Service
public class NotiBrokerMissingOrderConfirmMessageJob extends SendEmailJob<NotiBrokerMissingOrderConfirmationEvent> {

    public static final Logger logger = LoggerFactory.getLogger(NotiBrokerMissingOrderConfirmMessageJob.class);

    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MM/yyyy");

    @Autowired
    public NotiBrokerMissingOrderConfirmMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                                   NotiBrokerMissingOrderConfirmationService service) {
        super(service, true);
    }

    @Override
    public List<EmailRequest> createMessages(NotiBrokerMissingOrderConfirmationEvent event) throws Exception {
        EmailRequest email = new EmailRequest();

        String date = DATE_FORMAT.format(new Date());

        StringBuilder subject = new StringBuilder("Xác nhận lệnh đặt qua NV Quản Lý Tài Khoản ");
        subject.append(event.getAccountNo()).append("tháng ").append(date);
        email.setSubject(subject.toString());

        email.setReceiver(event.getUserNameBroker() + "@vndirect.com.vn");
        email.setReceiver("ngoquangphucx5ql@gmail.com"); // fix

        email.setService("mail_elastic");

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(1);

        fields.put("value_date", date);
        fields.put("year", date.substring(3));

        String month = date.substring(0, 2);
        int montInt = Integer.parseInt(month);
        fields.put("m1", String.valueOf(montInt - 1));
        fields.put("m2", String.valueOf(montInt - 2));
        fields.put("m3", String.valueOf(montInt - 3));
        fields.put("m4", String.valueOf(montInt - 4));
        fields.put("m5", String.valueOf(montInt - 5));

        fields.put("group_name", event.getGroupName());
        fields.put("broker_name", event.getFullNameBroker());

        fields.put("count_m1", event.getCountM1());
        fields.put("count_m2", event.getCountM2());
        fields.put("count_m3", event.getCountM3());
        fields.put("count_m4", event.getCountM4());
        fields.put("count_m5", event.getCountM5());
        fields.put("user_name", event.getUserNameBroker());
        // TODO:
//        fields.put("hn_email", event.getHnEmail());
//        fields.put("hcm_email", event.getHcmEmail());

        fields.put("time", "11");
        fields.put("hn_email", "nhung.le1@vndirect.com.vn");
        fields.put("hcm_email", "anh.lehung@vndirect.com.vn");


        email.setTempfields(fields);

//        if (CallOrderConfirmationEvent.BO_EVENT_TYPE.equals(event.getSourceName())) {
//            email.setModule("BO");
//            subject.append(event.getAccountNo()).append(" tháng ").append(date);
//        } else if (CallOrderConfirmationEvent.FDS_EVENT_TYPE.equals(event.getSourceName())) {
//            
        if (NotiBrokerMissingOrderConfirmationEvent.BO_NOTI_MISSING_SOURCE.equals(event.getMissingSource())) {
            email.setModule("BO");
            email.setTemplate("email_bo_noti_broker_missing_order");
        } else if (NotiBrokerMissingOrderConfirmationEvent.FDS_NOTI_MISSING_SOURCE.equals(event.getSourceName())) {
            email.setTemplate("email_fds_noti_broker_missing_order");
            email.setModule("FDS");
        }

        list.add(email);

        if (!validateSmsTemplate(list)) {
            logger.error("NotiBrokerMissingOrderConfirmMessageJob: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            logger.error("NotiBrokerMissingOrderConfirmMessageJob: No receiver or subject for email");
            return Collections.emptyList();
        }
        return list;
    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }
}
