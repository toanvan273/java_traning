/***************************************************************************
 * Copyright 2019 by VNDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.message.job.mail;

import com.homedirect.common.solr.repository.RepositoryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.customer.service.UserQueryService;
import vn.com.vndirect.event.model.Event;
import vn.com.vndirect.event.service.EventService;
import vn.com.vndirect.message.job.SendMessageJob;
import vn.com.vndirect.vndid.response.model.UserRecordResponse;
import vn.com.vndirect.vndid.response.model.UserResponse;

public abstract class SendEmailJob<E extends Event> extends SendMessageJob<E, EmailRequest> {

    @Autowired
    protected UserQueryService userQueryService;

    public SendEmailJob(EventService<E, ?> service, boolean enabled) {
        super(service, enabled);
    }


    public void loadReceiverByCustomerId(EmailRequest email, String customerId) throws RepositoryException {
        UserRecordResponse account  = userQueryService.searchByCustomerId(customerId);
        if(account == null) {
            throw new RepositoryException(111, "No customer found by id " + customerId);
        }

        UserResponse user = account.getUser();
        email.setReceiverId(user.getId());
        email.setReceiverName(user.getFullName());
        email.setCustID(customerId);
        email.setReceiver(user.getEmail());
    }

    protected void loadReceiverByAccountNo(EmailRequest email, String accountNo) throws RepositoryException {
        if(StringUtils.isEmpty(accountNo)) {
            throw new RepositoryException(111, "No customer found by accountNo " + accountNo);
        }
        
        UserRecordResponse account  = userQueryService.getCustomersByOrgByAccount(accountNo);
        if(account == null) {
            throw new RepositoryException(111, "No customer found by accountNo " + accountNo);
        }

        UserResponse user = account.getUser();
        email.setReceiverId(user.getId());
        email.setReceiverName(user.getFullName());
        email.setAccountNo(accountNo);
        email.setReceiver(user.getEmail());
    }

    protected EmailRequest cloneRequest(EmailRequest email) {
        EmailRequest newEmail = new EmailRequest();
        newEmail.setTemplate(email.getTemplate());

        newEmail.setSubject(email.getSubject());
        newEmail.setModule(email.getModule());

        newEmail.setReceiverId(email.getReceiverId());
        newEmail.setReceiverName(email.getReceiverName());
        newEmail.setReceiver(email.getReceiver());

        newEmail.setService(email.getService());
        return newEmail;
    }

    public String getQueryMessageType () {
        return " AND messageType_s:" + Event.EMAIL_MESSAGE_TYPE;
    }
}
