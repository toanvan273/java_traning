package vn.com.vndirect.message.job.mail.other;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.model.other.BoEmailNotiBankCashDepositEvent;
import vn.com.vndirect.event.other.BoEmailNotiBankCashDepositService;
import vn.com.vndirect.message.job.mail.SendEmailJob;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

// Email: Thông báo Nguồn vốn phát sinh giao dịch lớn
// @Service
public class BoEmailNotiBankCashDepositMessageJob extends SendEmailJob<BoEmailNotiBankCashDepositEvent> {
    public static final Logger LOGGER = LoggerFactory.getLogger(BoEmailNotiBankCashDepositMessageJob.class);

    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public BoEmailNotiBankCashDepositMessageJob(@Value("${fds.message-job.enabled}") Boolean enabled,
                                                BoEmailNotiBankCashDepositService service) {
        super(service, enabled);
    }

    @Override
    public List<EmailRequest> createMessages(BoEmailNotiBankCashDepositEvent event) throws Exception {
        EmailRequest email = new EmailRequest();

        String date = DATE_FORMAT.format(new Date());
        StringBuilder subject = new StringBuilder("Thông báo Nguồn vốn phát sinh giao dịch lớn ");
        subject.append("ngày ").append(date);

        email.setSubject(subject.toString());

        email.setTemplate("email_noti_generate_capital_major_transaction");

        email.setModule("BO");
        email.setService("mail_elastic");


        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(2);

        fields.put("trans_code", event.getTlTxCode());
        fields.put("amount_min", formatNumber("2000000000")); // TODO
        fields.put("amount", formatNumber(event.getAmount()));
        fields.put("txt_time", event.getTxTime());
        fields.put("bank", event.getReceivedBank());

        email.setTempfields(fields);

        // email.setReceiver("phong.kdtt@vndirect.com.vn"); // const
         email.setReceiver("ngoquangphucx5ql@gmail.com"); // test

        list.add(email);

        if (!validateEmailTemplate(list)) {
            LOGGER.error("Email Bank Cash Deposit Message Mapper: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            LOGGER.error("Email  Bank Cash Deposit Message Mapper: No receiver or subject for email");
            return Collections.emptyList();
        }

        return list;
    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateEmailTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }

    public String formatNumber(String number) {
        Locale localeEN = new Locale("en", "EN");
        NumberFormat numberFormat = NumberFormat.getInstance(localeEN);
        String numberFM = numberFormat.format(Long.parseLong(number));
        return numberFM;
    }
}
