/***************************************************************************
 * Copyright 2019 by VNDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.message.job.sms;

import com.homedirect.common.solr.repository.RepositoryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.customer.service.UserQueryService;
import vn.com.vndirect.event.model.Event;
import vn.com.vndirect.event.service.EventService;
import vn.com.vndirect.message.job.SendMessageJob;
import vn.com.vndirect.vndid.response.model.UserRecordResponse;
import vn.com.vndirect.vndid.response.model.UserResponse;

/**
 * Author : Nhu Dinh Thuan
 * Email:thuan.nhu@vndirect.com.vn
 * Nov 7, 2019
 */
public abstract class SendSmsJob<E extends Event> extends SendMessageJob<E, SMSRequest> {

    @Autowired
    protected UserQueryService userQueryService;

    public SendSmsJob(EventService<E, ?> service, boolean enabled) {
        super(service, enabled);
    }

    public SendSmsJob(EventService<E, ?> service, int delay, int poolSize, boolean enabled) {
        super(service, delay, poolSize, enabled);
    }

    public void loadReceiverByCustomerId(SMSRequest sms, String customerId) throws RepositoryException {
        UserRecordResponse account = userQueryService.searchByCustomerId(customerId);
        if (account == null) {
            throw new RepositoryException(111, "No customer found by id " + customerId);
        }

        UserResponse user = account.getUser();
        sms.setReceiverId(user.getId());
        sms.setReceiverName(user.getFullName());
        sms.setCustID(customerId);
        sms.setReceiverPhone(account.getUserProfile().getMobilePhone());
    }

    protected void loadReceiverByAccountNo(SMSRequest sms, String accountNo) throws RepositoryException {
        if (StringUtils.isEmpty(accountNo)) {
            throw new RepositoryException(111, "No customer found by accountNo " + accountNo);
        }

        UserRecordResponse account = userQueryService.getCustomersByOrgByAccount(accountNo);
        if (account == null) {
            throw new RepositoryException(111, "No customer found by accountNo " + accountNo);
        }

        UserResponse user = account.getUser();
        sms.setReceiverId(user.getId());
        sms.setReceiverName(user.getFullName());
        sms.setAccountNo(accountNo);
        sms.setReceiverPhone(account.getUserProfile().getMobilePhone());
    }

    protected SMSRequest cloneRequest(SMSRequest sms) {
        SMSRequest newSms = new SMSRequest();
        newSms.setTemplate(sms.getTemplate());

        newSms.setSubject(sms.getSubject());
        newSms.setModule(sms.getModule());

        newSms.setReceiverId(sms.getReceiverId());
        newSms.setReceiverName(sms.getReceiverName());
        newSms.setReceiverPhone(sms.getReceiverPhone());

        //co dinh, khong sua
        newSms.setBrandName(sms.getBrandName());
        newSms.setProvider(sms.getProvider());
        newSms.setService(sms.getService());

        return newSms;
    }

//    protected SMSRequest createSmsRequest() {
//        SMSRequest newSms = new SMSRequest();
//        newSms.setBrandName("VNDS");
//        newSms.setProvider("vndirect");
//        newSms.setService("sms");
//
//        return newSms;
//    }

    public String getQueryMessageType() {
        return " AND messageType_s:" + Event.SMS_MESSAGE_TYPE;
    }

}
