package vn.com.vndirect.message.job.mail.order;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.model.order.confirm.NotiCustomerMissingOrderConfirmationEvent;
import vn.com.vndirect.event.order.confirm.NotiCustomerMissingOrderConfirmationService;
import vn.com.vndirect.message.job.mail.SendEmailJob;

// Email: Thông báo Khách hàng/Môi giới thiếu phiếu lệnh cơ sở (BO)
// Email: Thông báo Khách hàng/Môi giới thiếu phiếu lệnh Phái Sinh (FDS)
// For customer


// Email: Thông báo Khách hàng thiếu phiếu lệnh cơ sở (BO)
// Email: Thông báo Khách hàng thiếu phiếu lệnh Phái Sinh (FDS)

// @Service
public class NotiCustomerMissingOrderConfirmMessageJob extends SendEmailJob<NotiCustomerMissingOrderConfirmationEvent> {

    public static final Logger logger = LoggerFactory.getLogger(NotiCustomerMissingOrderConfirmMessageJob.class);

    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MM/yyyy");

    @Autowired
    public NotiCustomerMissingOrderConfirmMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                                     NotiCustomerMissingOrderConfirmationService service) {
        super(service, enabled);
    }

    @Override
    public List<EmailRequest> createMessages(NotiCustomerMissingOrderConfirmationEvent event) throws Exception {
        EmailRequest email = new EmailRequest();

        String date = DATE_FORMAT.format(new Date());
        StringBuilder subject = new StringBuilder("Xác nhận lệnh đặt qua NV Quản Lý Tài Khoản ");

        email.setService("mail_elastic");

        email.setAccountNo(event.getAccountNo());

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(1);

        fields.put("customer_name", event.getFullNameCust());
        fields.put("account_no", event.getAccountNo());

        fields.put("count_m1", event.getCount());

        email.setTempfields(fields);

        if (NotiCustomerMissingOrderConfirmationEvent.BO_NOTI_MISSING_SOURCE.equals(event.getMissingSource())) {
            subject.append(event.getAccountNo()).append(" tháng ").append(date);
            email.setTemplate("email_bo_noti_customer_missing_order");
            email.setModule("BO");
        } else if (NotiCustomerMissingOrderConfirmationEvent.FDS_NOTI_MISSING_SOURCE.equals(event.getMissingSource())) {
            subject.append(event.getAccountNo()).append("P tháng ").append(date);
            email.setTemplate("email_fds_noti_customer_missing_order");
            email.setModule("FDS");
        }
        email.setSubject(subject.toString());
        email.setReceiver(event.getEmail());
        email.setReceiver("ngoquangphucx5ql@gmail.com"); // fix

        list.add(email);

        if (!validateSmsTemplate(list)) {
            logger.error("CallOrderConfirmationForCustomerMessageJob: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            logger.error("CallOrderConfirmationForCustomerMessageJob: No receiver or subject for email");
            return Collections.emptyList();
        }
        return list;
    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }
}
