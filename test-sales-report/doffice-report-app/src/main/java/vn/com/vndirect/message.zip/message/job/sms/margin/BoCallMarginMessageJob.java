package vn.com.vndirect.message.job.sms.margin;

import com.homedirect.common.solr.repository.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.margin.service.BoCallMarginService;
import vn.com.vndirect.event.margin.service.FileUploadHandleService;
import vn.com.vndirect.event.model.margin.BoCallMarginEvent;
import vn.com.vndirect.message.job.sms.SendSmsJob;

import java.text.SimpleDateFormat;
import java.util.*;

//Thông báo Nợ đến hạn cơ sở
// Nội dung Call Xử Lý : đối với T0, tplus
/*
     VNDIRECT TB: dd/mm/yy Quy khach co khoan no den han cua TK … la …d can thanh toan truoc ngay dd/mm/yy . Qua thoi han tren Cong ty se xu ly TK de thu no
 */
// SMS nội dung call nộp tiền trả nợ
/*
    VNDIRECT TB: dd/mm/yy Quy khach co khoan no den han cua TK … la …d can thanh toan truoc ngay dd/mm/yy. Qua thoi han tren he thong se tinh lai qua han theo quy dinh
 */

//@Service
public class BoCallMarginMessageJob extends SendSmsJob<BoCallMarginEvent> {

    public final static Logger logger = LoggerFactory.getLogger(BoCallMarginMessageJob.class);

    public final static String IGNORE_MARGIN_ACCOUNT_FILE_NAME = "DSTaiKhoanHoanCallMargin";

    public final static String IGNORE_MARGIN_TYPE_FILE_NAME = "DSLoaiHinhHoanCallMargin";

    @Autowired
    private FileUploadHandleService ignoreListService;

    protected SimpleDateFormat prinPeriodFormat = new SimpleDateFormat("yyyy-MM-dd");
    private final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public BoCallMarginMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                  BoCallMarginService service) {
        super(service, enabled);
    }

    public boolean isValidEvent(BoCallMarginEvent e) {
        if (ignoreListService.contains(IGNORE_MARGIN_ACCOUNT_FILE_NAME, e.getAccountNo())) return false;
        if (ignoreListService.contains(IGNORE_MARGIN_TYPE_FILE_NAME, e.getAfType())) return false;
        return true;
    }

    @Override
    public List<SMSRequest> createMessages(BoCallMarginEvent event) throws Exception {
        SMSRequest sms = createSmsRequest();

        sms.setSubject("FREE");
        sms.setModule("BO");

        sms.setAccountNo(event.getAccountNo());
        sms.setCustID(event.getCustId());

        List<String> callHandleType = Arrays.asList("T0 LOAN", "TPLUS");
        List<String> callForPayType = Arrays.asList("DF LOAN", "SL LOAN", "TN LOAN", "MARGIN LOAN");

        if (callHandleType.contains(event.getCategory())) {
            sms.setTemplate("sms_bo_call_margin_handle");
        }
        if (callForPayType.contains(event.getCategory())) {
            sms.setTemplate("sms_bo_call_margin_deposit");
        }

        Map<String, Object> fields = new HashMap<>();
        List<SMSRequest> list = new ArrayList<SMSRequest>(1);

        Date prinPeriod = prinPeriodFormat.parse(event.getPrinPeriod());
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(prinPeriod);
        calendar.add(Calendar.DATE, 1);
        String valueDate = DATE_FORMAT.format(calendar.getTime());
        String prin_period = DATE_FORMAT.format(prinPeriod);

        fields.put("value_date", valueDate);
        fields.put("prin_period", prin_period);

        fields.put("acct_no", event.getAccountNo());
        fields.put("prin_due", event.getPrinDue());

        sms.setTempFields(fields);
        list.add(sms);

        // TODO: check adding amount < 50k

        list.forEach(smsRequest -> {
            try {
                loadReceiver(smsRequest, event);
            } catch (RepositoryException e) {
                logger.error("Load receiver phone call margin event error for account :" + event.getAccountNo());
            }
        });

        if (!validateSmsTemplate(list)) {
            logger.error("Margin Message Mapper: No template or message content for sms");
            return Collections.emptyList();
        }

        if (!validateSmsReceiver(list)) {
            logger.error("Margin Message Mapper: No receiver or message content for sms");
            return Collections.emptyList();
        }
        return list;
    }

    protected SMSRequest createSmsRequest() {
        SMSRequest newSms = new SMSRequest();
        newSms.setBrandName("VNDS");
        newSms.setProvider("vndirect");
        newSms.setService("sms");

        return newSms;
    }

    protected void loadReceiver(SMSRequest sms, BoCallMarginEvent event) throws RepositoryException {
        if (!StringUtils.isEmpty(event.getPhone())) {
            sms.setReceiverPhone(event.getPhone());
            return;
        }
        if (!StringUtils.isEmpty(event.getCustId())) {
            loadReceiverByCustomerId(sms, event.getCustId());
            return;
        }

        loadReceiverByAccountNo(sms, event.getAccountNo());
    }

    private boolean validateSmsReceiver(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getReceiverId()) && StringUtils.isEmpty(sms.getReceiverPhone())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getMessage()) && StringUtils.isEmpty(sms.getTemplate())) return false;
        }
        return true;
    }
}
