package vn.com.vndirect.message.job.sms.ca;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.homedirect.common.solr.repository.RepositoryException;

import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.ca.service.BoNotiReturnCertificateService;
import vn.com.vndirect.event.model.ca.BoNotiReturnCertificateEvent;
import vn.com.vndirect.message.job.sms.SendSmsJob;

// Thông báo trả Giấy chứng nhận sở hữu khi trái phiếu đáo hạn
/*
    VNDIRECT TB: De tat toan TP <mã trái phiếu>, Quy khach vui long hoan tra Giay CNSH TP cho VNDIRECT truoc ngay dd/mm/yyyy. Chi tiet xin lien he 1900545409

 */

@Service
public class BoNotiReturnCertificateMessageJob extends SendSmsJob<BoNotiReturnCertificateEvent> {

    public final static Logger logger = LoggerFactory.getLogger(BoNotiReturnCertificateMessageJob.class);
    
//    private final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public BoNotiReturnCertificateMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                             BoNotiReturnCertificateService service) {
        super(service, enabled);
    }


    @Override
    public List<SMSRequest> createMessages(BoNotiReturnCertificateEvent event) throws Exception {
        SMSRequest sms = createSmsRequest();
        sms.setSubject("FREE");
        sms.setModule("BO");

        sms.setAccountNo(event.getAccountNo());
        sms.setCustID(event.getCustId());
        sms.setTemplate("sms_ca_noti_return_certificate");
        Map<String, Object> fields = new HashMap<>();
        List<SMSRequest> list = new ArrayList<SMSRequest>(1);

        fields.put("symbol", event.getBondCode());
        fields.put("return_due", event.getDateReturnRequired());
        sms.setTempFields(fields);
        list.add(sms);

        list.forEach(smsRequest -> {
            try {
                loadReceiver(smsRequest, event);
            } catch (RepositoryException e) {
                logger.error("Load receiver phone call BoNotiReturnCertificateEvent error for account :" + event.getAccountNo());
            }
        });

        if (!validateSmsTemplate(list)) {
            logger.error("BoNotiReturnCertificateEvent Message Mapper: No template or message content for sms");
            return Collections.emptyList();
        }

        if (!validateSmsReceiver(list)) {
            logger.error("BoNotiReturnCertificateEvent Message Mapper: No receiver or message content for sms");
            return Collections.emptyList();
        }
        return list;

    }

    protected SMSRequest createSmsRequest() {
        SMSRequest newSms = new SMSRequest();
        newSms.setBrandName("VNDS");
        newSms.setProvider("vndirect");
        newSms.setService("sms");

        return newSms;
    }

    protected void loadReceiver(SMSRequest sms, BoNotiReturnCertificateEvent event) throws RepositoryException {
        if (!StringUtils.isEmpty(event.getPhone())) {
            sms.setReceiverPhone(event.getPhone());
            return;
        }
        if (!StringUtils.isEmpty(event.getCustId())) {
            loadReceiverByCustomerId(sms, event.getCustId());
            return;
        }

        loadReceiverByAccountNo(sms, event.getAccountNo());
    }

    private boolean validateSmsReceiver(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getReceiverId()) && StringUtils.isEmpty(sms.getReceiverPhone())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getMessage()) && StringUtils.isEmpty(sms.getTemplate())) return false;
        }
        return true;
    }
}
