/***************************************************************************
 * Copyright 2019 by VNDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.message.mapper;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.transaction.TransactionChanged;
import vn.com.vndirect.message.job.sms.transaction.TransactionEventToMessageJob;

// Giao dịch Giảm tiền PS

public class FdsWithdrawCashToBankMessageMapper extends TransactionToMessageMapper {
    
    private final static Logger logger = LoggerFactory.getLogger(FdsWithdrawCashToBankMessageMapper.class);

    public FdsWithdrawCashToBankMessageMapper(TransactionEventToMessageJob job) {
        super(job, "DT60");
    }

    @Override
    protected boolean addDataFieldFromChanged(Map<String, Object> fields, TransactionChanged changed) {
        String balance = changed.getBalance();
        String amount = changed.getAmount();

        try {
            String balanceFm = numberFormat.format(Double.parseDouble(balance));
            String amountFm = numberFormat.format(Double.parseDouble(amount));

            fields.put("balance", balanceFm);
            fields.put("amount", amountFm);
            return true;
        } catch (RuntimeException e) {
            logger.error(e.toString() + " at class " + getClass().getSimpleName());
            return false;
        }
    }

    @Override
    protected boolean isValidChanged(TransactionChanged changed) {
        return super.isValidEventTypeAndBalance(changed, 'D');
    }

    @Override
    protected void setSmsMessageHeader(SMSRequest sms) {
        sms.setTemplate("sms_fds_withdraw_cash_to_bank");
        sms.setSubject("TRN");
        sms.setModule("FDS");
    }

}

