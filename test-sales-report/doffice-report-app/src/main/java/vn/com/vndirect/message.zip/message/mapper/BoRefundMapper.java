/***************************************************************************
 * Copyright 2019 by VNDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.message.mapper;

import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.transaction.TransactionChanged;
import vn.com.vndirect.message.job.sms.transaction.TransactionEventToMessageJob;

// Hoàn phí

public class BoRefundMapper extends TransactionToMessageMapper {

    public BoRefundMapper(TransactionEventToMessageJob job) {
        super(job, "1132");
    }

    @Override
    protected boolean isValidChanged(TransactionChanged changed) {
        return super.isValidEventTypeAndBalance(changed, 'C');
    }

    @Override
    protected void setSmsMessageHeader(SMSRequest sms) {
        sms.setTemplate("sms_bo_refund");
        sms.setSubject("TRN");
        sms.setModule("BO");
    }



}
