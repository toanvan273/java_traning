package vn.com.vndirect.message.job.sms.ca;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.homedirect.common.solr.repository.RepositoryException;

import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.ca.service.BoNotiProfitTakingDateService;
import vn.com.vndirect.event.model.ca.BoNotiProfitTakingDateEvent;
import vn.com.vndirect.message.job.sms.SendSmsJob;

// Thông báo ngày chốt trả lãi dịch vụ Quản lý cổ đông
/*
    VNDIRECT TB: Ngay dd/mm/yyyy VNDIRECT chot danh sach trai chu <mã TP> de thanh toan lai ngay dd/mm/yyyy. Quy khach vui long lien he 1900545409 de biet them chi tiet
 */

@Service
public class BoNotiProfitTakingDateEventMessageJob extends SendSmsJob<BoNotiProfitTakingDateEvent> {

    public final static Logger logger = LoggerFactory.getLogger(BoNotiProfitTakingDateEventMessageJob.class);
    
//    private final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public BoNotiProfitTakingDateEventMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                                 BoNotiProfitTakingDateService service) {
        super(service, enabled);
    }

    @Override
    public List<SMSRequest> createMessages(BoNotiProfitTakingDateEvent event) throws Exception {
        SMSRequest sms = createSmsRequest();
        sms.setSubject("FREE");
        sms.setModule("BO");

        sms.setAccountNo(event.getAccountNo());
        sms.setCustID(event.getCustId());
        sms.setTemplate("sms_ca_noti_profit_taking_date");

        Map<String, Object> fields = new HashMap<>();
        List<SMSRequest> list = new ArrayList<SMSRequest>(1);

        fields.put("report_date", event.getClosingDate());
        fields.put("symbol", event.getBondCode());
        fields.put("due_date", event.getPaymentDate());
        sms.setTempFields(fields);
        list.add(sms);

        list.forEach(smsRequest -> {
            try {
                loadReceiver(smsRequest, event);
            } catch (RepositoryException e) {
                logger.error("Load receiver phone call BoNotiProfitTakingDateEvent error for account :" + event.getAccountNo());
            }
        });

        if (!validateSmsTemplate(list)) {
            logger.error("BoNotiProfitTakingDateEvent Message Mapper: No template or message content for sms");
            return Collections.emptyList();
        }

        if (!validateSmsReceiver(list)) {
            logger.error("BoNotiProfitTakingDateEvent Message Mapper: No receiver or message content for sms");
            return Collections.emptyList();
        }
        return list;
    }

    protected SMSRequest createSmsRequest() {
        SMSRequest newSms = new SMSRequest();
        newSms.setBrandName("VNDS");
        newSms.setProvider("vndirect");
        newSms.setService("sms");

        return newSms;
    }

    protected void loadReceiver(SMSRequest sms, BoNotiProfitTakingDateEvent event) throws RepositoryException {
        if (!StringUtils.isEmpty(event.getPhone())) {
            sms.setReceiverPhone(event.getPhone());
            return;
        }
        if (!StringUtils.isEmpty(event.getCustId())) {
            loadReceiverByCustomerId(sms, event.getCustId());
            return;
        }

        loadReceiverByAccountNo(sms, event.getAccountNo());
    }

    private boolean validateSmsReceiver(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getReceiverId()) && StringUtils.isEmpty(sms.getReceiverPhone())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getMessage()) && StringUtils.isEmpty(sms.getTemplate())) return false;
        }
        return true;
    }
}
