/***************************************************************************
 * Copyright 2019 by VNDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.message.mapper;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.transaction.TransactionChanged;
import vn.com.vndirect.event.model.transaction.TransactionEvent;
import vn.com.vndirect.message.job.sms.transaction.TransactionEventToMessageJob;

// Nhận tiền bán Lô Lẻ
public class BoMatchTradeLotRetailMessageMapper extends TransactionToMessageMapper {

    public BoMatchTradeLotRetailMessageMapper(TransactionEventToMessageJob job) {
        super(job, "8879");
    }

    @Override
    protected boolean addDataFieldFromMultiChanged(Map<String, Object> fields, List<TransactionChanged> changed) {
        boolean found = super.addDataFieldFromMultiChanged(fields, changed);
        Optional<TransactionChanged> changedWithSymbol = changed.stream().filter(change -> !StringUtils.isEmpty(change.getSymbol())).findFirst();
        if (!changedWithSymbol.isPresent()) return false;
        fields.put("symbol", changedWithSymbol.get().getSymbol());
        return found;
    }

    @Override
    protected boolean isValidChanged(TransactionChanged changed) {
        // return super.isValidBalanceAndSymBol(changed, 'C');
        return super.isValidBalance(changed);
    }

    @Override
    protected void setSmsMessageHeader(SMSRequest sms) {
        sms.setTemplate("sms_bo_match_trade_lot_retail");
        sms.setSubject("TRN");
        sms.setModule("BO");
    }

    @Override
    public List<SMSRequest> apply(TransactionEvent event) {
        event.setMultiChangeMapperToMessage(true);
        return super.apply(event);
    }

}
