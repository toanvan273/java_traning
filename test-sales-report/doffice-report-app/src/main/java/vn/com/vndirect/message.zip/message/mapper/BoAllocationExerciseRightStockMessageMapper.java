/***************************************************************************
 * Copyright 2019 by VNDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.message.mapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.transaction.TransactionChanged;
import vn.com.vndirect.message.job.sms.transaction.TransactionEventToMessageJob;

import java.util.Map;

// Nhận cổ tức bằng CP

public class BoAllocationExerciseRightStockMessageMapper extends TransactionToMessageMapper {

    private final static Logger logger = LoggerFactory.getLogger(BoAllocationExerciseRightStockMessageMapper.class);

    public BoAllocationExerciseRightStockMessageMapper(TransactionEventToMessageJob job) {
        super(job, "3379");
    }

    @Override
    protected boolean addDataFieldFromChanged(Map<String, Object> fields, TransactionChanged changed) {
        String trade = changed.getTrade();
        try {
            String tradeFm = numberFormat.format(Integer.parseInt(trade));

            fields.put("trade", tradeFm);
            fields.put("symbol", changed.getSymbol());
            return true;
        } catch (RuntimeException e) {
            logger.error(e.toString() + " at class " + getClass().getSimpleName());
            return false;
        }
    }

    @Override
    protected boolean isValidChanged(TransactionChanged changed) {
        return super.isValidTrade(changed, 'C');
    }

    @Override
    protected void setSmsMessageHeader(SMSRequest sms) {
        sms.setTemplate("sms_bo_allocation_exercise_right_stock");
        sms.setSubject("TRN");
        sms.setModule("BO");
    }

}
