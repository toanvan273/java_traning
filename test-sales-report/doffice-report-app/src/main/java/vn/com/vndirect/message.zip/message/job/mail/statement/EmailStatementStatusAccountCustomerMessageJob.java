package vn.com.vndirect.message.job.mail.statement;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.homedirect.common.solr.repository.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.model.statement.EmailStatementStatusAccountCustomerEvent;
import vn.com.vndirect.event.statement.EmailStatementStatusAccountCustomerService;
import vn.com.vndirect.message.job.mail.SendEmailJob;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;


// Sao Kê: Gửi email sao kê định kỳ cuối tháng trạng thái tài khoản

@Service
public class EmailStatementStatusAccountCustomerMessageJob extends SendEmailJob<EmailStatementStatusAccountCustomerEvent> {

    public static final Logger logger = LoggerFactory.getLogger(EmailStatementStatusAccountCustomerMessageJob.class);

    public static final SimpleDateFormat DATE_DB = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    public static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm:ss");

    @Autowired
    public EmailStatementStatusAccountCustomerMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                                         EmailStatementStatusAccountCustomerService service) {
        super(service, enabled);
    }

    @Override
    public List<EmailRequest> createMessages(EmailStatementStatusAccountCustomerEvent event) throws Exception {
        EmailRequest email = new EmailRequest();

        StringBuilder subject = new StringBuilder("Báo cáo tài sản tài khoản ");
        subject.append(event.getAccountNo());

        email.setSubject(subject.toString());
        email.setTemplate("email_statement_status_account_customer");
        email.setReceiver(event.getEmail());

        email.setModule("BO");
        email.setService("mail_elastic");

        email.setAccountNo(event.getAccountNo());

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(1);

        fields.put("customer_name", event.getFullName());
        fields.put("account_no", event.getAccountNo());
        fields.put("from_date", "20-12-2019"); // TODO
        fields.put("to_date", "25-12-2019"); // TODO

        int cash = 0;
        int totalMoney = 0;
        int stock = 0;
        int ccq = 0;
        int bond = 0;
        int derivative = 0;
        int insurance = 0;
        int loan = 0;
        int netAssets = 0;

        cash = Integer.parseInt(event.getCiBalance()) + Integer.parseInt(event.getCiBlock())
                + Integer.parseInt(event.getTdAmt()); // TODO

        totalMoney = cash + Integer.parseInt(event.getCiReceiving());

        stock = Integer.parseInt(event.getStockAndRightsSavings()) + Integer.parseInt(event.getStockAndRightsDMA())
                + Integer.parseInt(event.getStockAndRightsEntrust()) + Integer.parseInt(event.getStockAndRightsInvestment())
                + Integer.parseInt(event.getStockAndRightsPM()) + Integer.parseInt(event.getStockBrokerage())
                + Integer.parseInt(event.getStockTrading());

        ccq = Integer.parseInt(event.getdCashFund()) + Integer.parseInt(event.getFundUnitSavings())
                + Integer.parseInt(event.getFundUnitBrokerage()) + Integer.parseInt(event.getFundUnitDMA())
                + Integer.parseInt(event.getFundUnitEntrust()) + Integer.parseInt(event.getFundUnitInvestment())
                + Integer.parseInt(event.getFundUnitPM()) + Integer.parseInt(event.getFundUnitTrading());

        bond = Integer.parseInt(event.getBondAndRightsSavings()) + Integer.parseInt(event.getBondAndRightsDMA())
                + Integer.parseInt(event.getBondAndRightsEntrust()) + Integer.parseInt(event.getBondAndRightsInvestment())
                + Integer.parseInt(event.getBondAndRightsPM()) + Integer.parseInt(event.getBondBrokerage())
                + Integer.parseInt(event.getBondTrading());

        derivative = Integer.parseInt(event.getDerivativeBrokerage()) + Integer.parseInt(event.getDerivativeTrading());

        insurance = Integer.parseInt(event.getLifeInsurance()) + Integer.parseInt(event.getNonLifeInsurance());

        loan = Integer.parseInt(event.getMargin()) + Integer.parseInt(event.getOverDraftLoan())
                + Integer.parseInt(event.getDepositoryFee()) + Integer.parseInt(event.getOverdueDepositoryFee());

        netAssets = Integer.parseInt(event.getdCash()) + Integer.parseInt(event.getdWealth())
                + Integer.parseInt(event.getdTrade());

        fields.put("total_money", formatNumber(String.valueOf(totalMoney)));
        fields.put("cash", formatNumber(String.valueOf(cash)));
        fields.put("receiving", formatNumber(event.getCiReceiving()));
        fields.put("stock", formatNumber(String.valueOf(stock)));
        fields.put("warrant", "0"); // TODO
        fields.put("ccq", formatNumber(String.valueOf(ccq)));
        fields.put("bond", formatNumber(String.valueOf(bond)));
        fields.put("derivative", formatNumber(String.valueOf(derivative)));
        fields.put("insurance", formatNumber(String.valueOf(insurance)));
        fields.put("loan", formatNumber(String.valueOf(loan)));
        fields.put("net_assets", formatNumber(String.valueOf(netAssets)));
        fields.put("total_loan", formatNumber(String.valueOf(loan))); // TODO

        email.setTempfields(fields);

        list.add(email);

        list.forEach(emailRequest -> {
            try {
                loadReceiver(emailRequest, event);
            } catch (RepositoryException e) {
                logger.error("Load receiver phone call Email STATEMENT error for account :" + event.getAccountNo());
            }
        });

        if (!validateSmsTemplate(list)) {
            logger.error("Email STATEMENT Message Mapper: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            logger.error("Email STATEMENT Message Mapper: No receiver or subject for email");
            return Collections.emptyList();
        }
        return list;
    }

    public String formatNumber(String number) {
        Locale localeEN = new Locale("en", "EN");
        NumberFormat numberFormat = NumberFormat.getInstance(localeEN);
        String numberFM = numberFormat.format(Long.parseLong(number));
        return numberFM;
    }

    protected void loadReceiver(EmailRequest email, EmailStatementStatusAccountCustomerEvent event) throws RepositoryException {

        email.setReceiver("ngoquangphucx5ql@gmail.com");

        if (!StringUtils.isEmpty(event.getCustId())) {
            loadReceiverByCustomerId(email, event.getCustId());
            return;
        }

        loadReceiverByAccountNo(email, event.getAccountNo());
    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }
}
