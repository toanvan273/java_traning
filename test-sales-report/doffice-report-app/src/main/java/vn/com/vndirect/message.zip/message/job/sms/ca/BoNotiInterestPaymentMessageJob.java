package vn.com.vndirect.message.job.sms.ca;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.homedirect.common.solr.repository.RepositoryException;

import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.ca.service.BoNotiInterestPaymentService;
import vn.com.vndirect.event.model.ca.BoNotiInterestPaymentEvent;
import vn.com.vndirect.message.job.sms.SendSmsJob;

// Thông báo đã trả lãi xong của dịch vụ Quản lý cổ đông

/*
  VNDIRECT TB: Ngay dd/mm/yyyy <Tên TCPH> da thuc hien tra lai dot <số đợt> trai phieu <Mã TP>. Quy khach vui long lien he 1900545409 de biet them chi tiet
 */

@Service
public class BoNotiInterestPaymentMessageJob extends SendSmsJob<BoNotiInterestPaymentEvent> {

    public final static Logger logger = LoggerFactory.getLogger(BoNotiInterestPaymentMessageJob.class);
    
//    private final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public BoNotiInterestPaymentMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                           BoNotiInterestPaymentService service) {
        super(service, enabled);
    }

    @Override
    public List<SMSRequest> createMessages(BoNotiInterestPaymentEvent event) throws Exception {
        SMSRequest sms = createSmsRequest();
        sms.setSubject("FREE");
        sms.setModule("BO");

        sms.setAccountNo(event.getAccountNo());
        sms.setCustID(event.getCustId());
        sms.setTemplate("sms_ca_noti_interest_payment");

        Map<String, Object> fields = new HashMap<>();
        List<SMSRequest> list = new ArrayList<SMSRequest>(1);

        fields.put("due_date", event.getPaymentDate());
        fields.put("company", event.getBondCode());
        fields.put("number_payment", event.getNumbersOfPayment());
        fields.put("symbol", event.getBondCode());
        sms.setTempFields(fields);
        list.add(sms);

        list.forEach(smsRequest -> {
            try {
                loadReceiver(smsRequest, event);
            } catch (RepositoryException e) {
                logger.error("Load receiver phone call BoNotiInterestPaymentEvent error for account :" + event.getAccountNo());
            }
        });

        if (!validateSmsTemplate(list)) {
            logger.error("BoNotiInterestPaymentEvent Message Mapper: No template or message content for sms");
            return Collections.emptyList();
        }

        if (!validateSmsReceiver(list)) {
            logger.error("BoNotiInterestPaymentEvent Message Mapper: No receiver or message content for sms");
            return Collections.emptyList();
        }
        return list;
    }

    protected SMSRequest createSmsRequest() {
        SMSRequest newSms = new SMSRequest();
        newSms.setBrandName("VNDS");
        newSms.setProvider("vndirect");
        newSms.setService("sms");

        return newSms;
    }

    protected void loadReceiver(SMSRequest sms, BoNotiInterestPaymentEvent event) throws RepositoryException {
        if (!StringUtils.isEmpty(event.getPhone())) {
            sms.setReceiverPhone(event.getPhone());
            return;
        }
        if (!StringUtils.isEmpty(event.getCustId())) {
            loadReceiverByCustomerId(sms, event.getCustId());
            return;
        }

        loadReceiverByAccountNo(sms, event.getAccountNo());
    }

    private boolean validateSmsReceiver(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getReceiverId()) && StringUtils.isEmpty(sms.getReceiverPhone())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getMessage()) && StringUtils.isEmpty(sms.getTemplate())) return false;
        }
        return true;
    }
}
