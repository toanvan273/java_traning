package vn.com.vndirect.message.job.mail.ca;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.ca.service.BoNotiIPOResultsService;
import vn.com.vndirect.event.model.ca.BoNotiIPOResultsEvent;
import vn.com.vndirect.message.job.mail.SendEmailJob;

import java.text.SimpleDateFormat;
import java.util.*;

// Email thông báo kết quả IPO CW

//@Service
public class BoEmailNotiIPOResultsMessageJob extends SendEmailJob<BoNotiIPOResultsEvent> {

    public static final Logger LOGGER = LoggerFactory.getLogger(BoEmailNotiMadeRightCustomerMessageJob.class);
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    public BoEmailNotiIPOResultsMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                           BoNotiIPOResultsService service) {
        super(service, enabled);
    }

    @Override
    public List<EmailRequest> createMessages(BoNotiIPOResultsEvent event) throws Exception {
        EmailRequest email = new EmailRequest();

        StringBuilder subject = new StringBuilder("Thông báo kết quả IPO CW cho Khách hàng tài khoản số ");
        subject.append(event.getAccountNo());

        email.setSubject(subject.toString());

        email.setTemplate("email_noti_auction_ca");

        email.setModule("BO");
        email.setService("mail_elastic");

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(1);

        fields.put("customer_name", event.getFullNameCust());
        fields.put("account_no", event.getAccountNo());
        fields.put("symbol", event.getSymbol());
        fields.put("qtty", event.getQuantity());
        fields.put("price", event.getWarrantPrice());
        fields.put("price_trans", event.getTransactionValue());
        fields.put("cash_amount", event.getAmountPaid());
        fields.put("certificate", event.getWarrantCode());
        fields.put("company", event.getIssuersName());
        fields.put("due_months", event.getTermMonth());
        fields.put("release_date", event.getReleaseDate());
        fields.put("due_date", event.getDueDate());
        fields.put("last_trans_date", event.getTransactionLastDate());
        fields.put("ex_price", event.getPrice());

        email.setTempfields(fields);
        email.setReceiver(event.getEmail());
        // TODO: test
        email.setReceiver("phongnhatran2893@gmail.com");
        list.add(email);

        if (!validateEmailTemplate(list)) {
            LOGGER.error("Email BoNotiIPOResultsEvent: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            LOGGER.error("Email BoNotiIPOResultsEvent: No receiver or subject for email");
            return Collections.emptyList();
        }

        return list;

    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateEmailTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }
}
