package vn.com.vndirect.message.job.mail.ca;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.ca.service.BoNotiExpireSubscriptRightRegisterService;
import vn.com.vndirect.event.model.ca.BoNotiExpireSubscriptRightRegisterEvent;
import vn.com.vndirect.message.job.mail.SendEmailJob;

import java.text.SimpleDateFormat;
import java.util.*;

// Coporate Action: Thông báo hết hạn đăng ký quyền mua

//@Service
public class BoEmailNotiExpireSubscriptRightRegisterMessageJob extends SendEmailJob<BoNotiExpireSubscriptRightRegisterEvent> {

    public static final Logger LOGGER = LoggerFactory.getLogger(BoEmailNotiExpireSubscriptRightRegisterMessageJob.class);
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public BoEmailNotiExpireSubscriptRightRegisterMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled, BoNotiExpireSubscriptRightRegisterService service) {
        super(service, enabled);
    }

    @Override
    public List<EmailRequest> createMessages(BoNotiExpireSubscriptRightRegisterEvent event) throws Exception {
        EmailRequest email = new EmailRequest();
        StringBuilder subject = new StringBuilder("Thông báo hết hạn đăng ký quyền mua cho khách hàng có quyền");
        subject.append(event.getAccountNo());

        email.setSubject(subject.toString());

        email.setModule("BO");
        email.setService("mail_elastic");
        email.setTemplate("email_noti_stock_issuing_right_customer_ca");

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(1);

        fields.put("customer_name", event.getFullNameCust());
        fields.put("symbol", event.getSymbol());
        fields.put("company", event.getIssuersName());

        fields.put("report_date", event.getReportDate());
        fields.put("right_off_rate", event.getRightOffRate());
        fields.put("ex_price", event.getExPrice());
        fields.put("fr_date_transfer", event.getFrDateTransfer());
        fields.put("to_date_transfer", event.getToDateTransfer());
        fields.put("due_date", event.getDueDate());

        email.setTempfields(fields);
        email.setReceiver(event.getEmail());
        // TODO: test
        email.setReceiver("Nguyentientho110@gmail.com");
        list.add(email);

        if (!validateEmailTemplate(list)) {
            LOGGER.error("BoNotiExpireSubscriptRightRegisterEvent: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            LOGGER.error("BoNotiExpireSubscriptRightRegisterEvent: No receiver or subject for email");
            return Collections.emptyList();
        }

        return list;
    }


    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateEmailTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }

}
