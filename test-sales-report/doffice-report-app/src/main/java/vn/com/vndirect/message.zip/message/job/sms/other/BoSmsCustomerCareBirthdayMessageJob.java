package vn.com.vndirect.message.job.sms.other;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.other.BoSmsCustomerCareBirthdayEvent;
import vn.com.vndirect.event.other.BoSmsCustomerCareBirthdayService;
import vn.com.vndirect.message.job.sms.SendSmsJob;

import java.util.*;

// Customers Care: SMS chúc mừng SN khách hàng

/*
 * VNDIRECT kinh chuc Quy khach .... (enfullname)... sinh nhat vui ve, tran day suc khoe.
 *  Chan thanh cam on Quy khach da tin tuong và dong hanh cung VNDIRECT.
 */

@Service
public class BoSmsCustomerCareBirthdayMessageJob extends SendSmsJob<BoSmsCustomerCareBirthdayEvent> {

    public final static Logger logger = LoggerFactory.getLogger(BoSmsCustomerCareBirthdayMessageJob.class);

    @Autowired
    public BoSmsCustomerCareBirthdayMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                               BoSmsCustomerCareBirthdayService service) {
        super(service, enabled);
    }

    @Override
    public List<SMSRequest> createMessages(BoSmsCustomerCareBirthdayEvent event) throws Exception {
        SMSRequest sms = createSmsRequest();

        sms.setSubject("FREE");
        sms.setModule("BO");

        sms.setAccountNo(event.getAccountNo());
        sms.setCustID(event.getCustId());

        sms.setReceiverPhone(event.getPhone());
        sms.setReceiverPhone("0001001034"); // TODO

        sms.setTemplate("sms_customers_care_birthday");

        Map<String, Object> fields = new HashMap<>();
        List<SMSRequest> list = new ArrayList<SMSRequest>(1);

        fields.put("en_full_name", event.getFullNameCust());

        sms.setTempFields(fields);
        list.add(sms);

        if (!validateSmsTemplate(list)) {
            logger.error("Customer Birthday Message Mapper: No template or message content for sms");
            return Collections.emptyList();
        }

        if (!validateSmsReceiver(list)) {
            logger.error("Customer Birthday  Message Mapper: No receiver or message content for sms");
            return Collections.emptyList();
        }
        return list;
    }

    protected SMSRequest createSmsRequest() {
        SMSRequest newSms = new SMSRequest();
        newSms.setBrandName("VNDS");
        newSms.setProvider("vndirect");
        newSms.setService("sms");

        return newSms;
    }

    private boolean validateSmsReceiver(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getReceiverId()) && StringUtils.isEmpty(sms.getReceiverPhone())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getMessage()) && StringUtils.isEmpty(sms.getTemplate())) return false;
        }
        return true;
    }
}
