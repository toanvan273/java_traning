/***************************************************************************
 * Copyright 2019 by VNDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.message.job;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import vn.com.vndirect.communication.request.MessageRequest;
import vn.com.vndirect.event.common.ExecutableJob;
import vn.com.vndirect.event.common.message.config.MessageConfig;
import vn.com.vndirect.event.common.message.config.MessageConfigStorage;
import vn.com.vndirect.event.model.Event;
import vn.com.vndirect.event.service.EventService;

import java.util.List;
/*import vn.com.vndirect.message.config.MessageConfig;
import vn.com.vndirect.message.config.MessageConfigStorage;*/

/**
 * Author : Nhu Dinh Thuan
 * Email:thuan.nhu@vndirect.com.vn
 * Oct 17, 2019
 */
public abstract class SendMessageJob<E extends Event, M extends MessageRequest> extends ExecutableJob {

    private final static Logger logger = LoggerFactory.getLogger(SendMessageJob.class);

    protected EventService<E, ?> service;

    protected MessageConfig config;

    protected RestTemplate restTemplate;

    @Autowired
    private ObjectMapper mapper;

    private boolean enabled = true;

    public SendMessageJob(EventService<E, ?> service, boolean enabled) {
        this(service, 10);
        this.enabled = enabled;
        if (!enabled) logger.info(getClass().getSimpleName() + " is disabled!");
    }

    public SendMessageJob(EventService<E, ?> service, int delay) {
        super(delay);
        this.service = service;
    }

    public SendMessageJob(EventService<E, ?> service, int delay, int poolSize, boolean enabled) {
        super(delay, poolSize);
        this.enabled = enabled;
        this.service = service;
    }

    @Autowired
    public void setMessageConfigStorage(MessageConfigStorage configStorage) {
        config = configStorage.getConfig(service.getEventType());
        if (config == null) {
            logger.error("No Message Config for " + service.getEventType());
            System.exit(0);
        }
        restTemplate = new RestTemplate();
    }

    @Override
    public void execute() {
        if (!enabled) return;
        try {
            List<E> events = service.queryForAlert(); //getQueryMessageType()
            logger.info("-------> query event for sending " + events.size());
            if (events.isEmpty()) return;
            events.forEach(event -> {
//                if (isValidEvent(event)) {
//                    alert(event);
//                } else {
                    service.updateDisabled(event);
//                }
            });
        } catch (Exception e) {
            logger.error(e.toString(), e);
        }
    }

//    @SuppressWarnings("unused")
//    public boolean isValidEvent(E e) {
//        return true;
//    }

    protected void alert(E event) {
        try {
            logger.info("Message Service : " + event.getSourceName() + " - Found " + " events for alerting...");
            if (StringUtils.isEmpty(event.getEventId())) {
                logger.info("Event Id not found  " + event);
                return;
            }
            List<M> messages = createMessages(event);
            logger.error("Found " + event.getEventId() + " : " + messages);
            if (messages.isEmpty()) {
                event.setEventStatus(Event.NO_THING_IO_SENT);
                service.updateStatus(event);
                return;
            }

//            System.out.println("json---> " + mapper.writeValueAsString(messages.get(0)));
            logger.info("-----------/////////-------Message : " + mapper.writeValueAsString(messages));
            messages.forEach(message -> {
                if (message == null) {
                    logger.error("Found " + event.getEventId() + ", message null ");
                    return;
                }
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                HttpEntity<M> entity = new HttpEntity<M>(message, headers);

                if ("mail_elastic".equals(message.getService())) {
                    try {
                        logger.info("Send message " + mapper.writeValueAsString(message) + " to " + config.getUrlEmail());
                    } catch (JsonProcessingException e) {
                        logger.error(e.toString());
                    }

                    ResponseEntity<Object> responseEntity = restTemplate.postForEntity(config.getUrlEmail(), entity, Object.class);
                    logger.info("result: " + responseEntity.getStatusCodeValue() + " : " + responseEntity.getBody());

                } else {
                    try {
                        logger.info("Send message " + mapper.writeValueAsString(message) + " to " + config.getUrl());
                    } catch (Exception e) {
                        logger.error(e.toString());
                    }

                    ResponseEntity<String> response = restTemplate.postForEntity(config.getUrl(), entity, String.class);
                    logger.info("result: " + response.getStatusCodeValue() + " : " + response.getBody());

                }
            });

            event.setEventStatus(Event.SENT);
            service.updateSent(event);
        } catch (Exception exp) {
            logger.error(exp.getMessage(), exp);
            service.updateDisabled(event);
        }
    }

    public abstract List<M> createMessages(E event) throws Exception;

    public abstract String getQueryMessageType();

}
