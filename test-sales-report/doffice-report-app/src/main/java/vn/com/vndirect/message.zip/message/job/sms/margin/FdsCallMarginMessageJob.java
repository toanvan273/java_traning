package vn.com.vndirect.message.job.sms.margin;

import com.homedirect.common.solr.repository.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.margin.service.FdsCallOverdraftService;
import vn.com.vndirect.event.margin.service.FileUploadHandleService;
import vn.com.vndirect.event.model.margin.FdsMarginEvent;
import vn.com.vndirect.message.job.sms.SendSmsJob;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

// Thông báo nợ đến hạn phái sinh

/*
 * VNDIRECT TB: De nghi chu TK …P thanh toan so no thau chi … truoc 13h00 ngay dd/mm/yyyy.
 * Qua thoi han tren, cong ty se xu ly TK de thu no.
 */

@Service
public class FdsCallMarginMessageJob extends SendSmsJob<FdsMarginEvent> {

    public final static String IGNORE_FDS_ACCOUNT_FILE_NAME = "DSTaiKhoanHoanCallFds";

    @Autowired
    private FileUploadHandleService ignoreListService;

    public final static Logger logger = LoggerFactory.getLogger(FdsCallMarginMessageJob.class);

    private final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public FdsCallMarginMessageJob(@Value("${fds.message-job.enabled}") Boolean enabled,
                                   FdsCallOverdraftService service) {
        super(service, enabled);
    }

    public boolean isValidEvent(FdsMarginEvent e) {
        if (ignoreListService.contains(IGNORE_FDS_ACCOUNT_FILE_NAME, e.getAccountNo())) return false;
        return true;
    }

    @Override
    public List<SMSRequest> createMessages(FdsMarginEvent event) throws Exception {
        SMSRequest sms = createSmsRequest();

        sms.setSubject("FREE");
        sms.setModule("BO");

        sms.setAccountNo(event.getAccountNo());
        sms.setCustID(event.getCustId());

        sms.setTemplate("sms_fds_call_over_draft");

        Map<String, Object> fields = new HashMap<>();
        List<SMSRequest> list = new ArrayList<SMSRequest>(1);

        String dateDue = DATE_FORMAT.format(new Date());

        fields.put("date_due", dateDue);

        fields.put("acct_no", event.getAccountNo());

        String debtAmt = event.getDebtAmt();
        Locale localeEN = new Locale("en", "EN");
        NumberFormat en = NumberFormat.getInstance(localeEN);
        String debtAmtFm = en.format(Double.parseDouble(debtAmt));

        fields.put("debt_amt", debtAmtFm);

        sms.setTempFields(fields);
        list.add(sms);

        list.forEach(smsRequest -> {
            logger.info("Sms Request: ................> " + smsRequest);
            try {
                loadReceiver(smsRequest, event);
            } catch (RepositoryException e) {
                logger.error("Load receiver phone order event error for account :" + event.getAccountNo());
            }
        });

        if (!validateSmsTemplate(list)) {
            logger.error("Margin Message Mapper: No template or message content for sms");
            return Collections.emptyList();
        }

        if (!validateSmsReceiver(list)) {
            logger.error("Margin Message Mapper: No receiver or message content for sms");
            return Collections.emptyList();
        }
        return list;
    }

    protected SMSRequest createSmsRequest() {
        SMSRequest newSms = new SMSRequest();
        newSms.setBrandName("VNDS");
        newSms.setProvider("vndirect");
        newSms.setService("sms");

        return newSms;
    }

    protected void loadReceiver(SMSRequest sms, FdsMarginEvent event) throws RepositoryException {
        if (!StringUtils.isEmpty(event.getPhone())) {
            sms.setReceiverPhone(event.getPhone());
            return;
        }
        if (!StringUtils.isEmpty(event.getCustId())) {
            loadReceiverByCustomerId(sms, event.getCustId());
            return;
        }

        loadReceiverByAccountNo(sms, event.getAccountNo());
    }

    private boolean validateSmsReceiver(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getReceiverId()) && StringUtils.isEmpty(sms.getReceiverPhone())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getMessage()) && StringUtils.isEmpty(sms.getTemplate())) return false;
        }
        return true;
    }
}
