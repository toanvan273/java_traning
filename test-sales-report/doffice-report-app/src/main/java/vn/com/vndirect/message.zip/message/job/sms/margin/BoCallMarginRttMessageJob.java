package vn.com.vndirect.message.job.sms.margin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.homedirect.common.solr.repository.RepositoryException;

import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.margin.service.BoCallMarginRttService;
import vn.com.vndirect.event.margin.service.FileUploadHandleService;
import vn.com.vndirect.event.model.margin.BoCallMarginRttEvent;
import vn.com.vndirect.message.job.sms.SendSmsJob;

// Thông báo tỷ lệ Rtt đối với tài sản cơ sở
// Nội dung Call Xử Lý : đối với tài khoản có tỷ lệ Rtt dưới 85%
/*
    VNDIRECT TB: dd/mm/yy Ty le tai san/no cua TK … la …%.Cong ty se xu ly TK de thu no. Lien he:NVQLTK hoac 1900545409 de biet chi tiet
*/

// Nội dung Call bổ sung Tài sản : đối với tài khoản có tỷ lệ Rtt từ 85% -> 90%
/*
    VNDIRECT TB: dd/mm/yyy Ty le tai san/no cua TK … la …%.Quy khach vui long bo sung tien de ty le >= 90%. Lien he: NVQLTK hoac 1900545409 de biet chi tiet
 */

//@Service
public class BoCallMarginRttMessageJob extends SendSmsJob<BoCallMarginRttEvent> {

    public final static String IGNORE_RTT_ACCOUNT_FILE_NAME = "DSTaiKhoanHoanCallRtt";

    public final static String IGNORE_RTT_TYPE_FILE_NAME = "DSTaiKhoanHoanCallRtt";

    public final static Logger logger = LoggerFactory.getLogger(BoCallMarginRttMessageJob.class);

    @Autowired
    private FileUploadHandleService ignoreListService;

    @Autowired
    public BoCallMarginRttMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                     BoCallMarginRttService service) {
        super(service, enabled);
    }

    public boolean isValidEvent(BoCallMarginRttEvent e) {
        if (ignoreListService.contains(IGNORE_RTT_ACCOUNT_FILE_NAME, e.getAccountNo())) return false;
        if (ignoreListService.contains(IGNORE_RTT_TYPE_FILE_NAME, e.getAfType())) return false;
        return true;
    }

    @Override
    public List<SMSRequest> createMessages(BoCallMarginRttEvent event) throws Exception {
        SMSRequest sms = createSmsRequest();

        sms.setSubject("FREE");
        sms.setModule("BO");

        sms.setAccountNo(event.getAccountNo());
        sms.setCustID(event.getCustId());
        sms.setMessage(event.getContent());

        try {
            loadReceiver(sms, event);
        } catch (RepositoryException e) {
            logger.error("Load receiver phone order event error for account :" + event.getAccountNo());
        }

        List<SMSRequest> list = new ArrayList<SMSRequest>(1);
        list.add(sms);
        list.forEach(smsRequest -> {
            try {
                loadReceiver(smsRequest, event);
            } catch (RepositoryException e) {
                logger.error("Load receiver phone order event error for account :" + event.getAccountNo());
            }
        });
        if (!validateSmsReceiver(list)) {
            logger.error("Margin Message Mapper: No receiver or message content for sms");
            return Collections.emptyList();
        }

        return list;
    }

    protected SMSRequest createSmsRequest() {
        SMSRequest newSms = new SMSRequest();
        newSms.setBrandName("VNDS");
        newSms.setProvider("vndirect");
        newSms.setService("sms");

        return newSms;
    }

    protected void loadReceiver(SMSRequest sms, BoCallMarginRttEvent event) throws RepositoryException {
        if (!StringUtils.isEmpty(event.getPhone())) {
            sms.setReceiverPhone(event.getPhone());
            return;
        }
        if (!StringUtils.isEmpty(event.getCustId())) {
            loadReceiverByCustomerId(sms, event.getCustId());
            return;
        }

        loadReceiverByAccountNo(sms, event.getAccountNo());
    }

    private boolean validateSmsReceiver(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getReceiverId()) && StringUtils.isEmpty(sms.getReceiverPhone())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getMessage()) && StringUtils.isEmpty(sms.getTemplate())) return false;
        }
        return true;
    }
}
