package vn.com.vndirect.message.job.mail.other;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.model.other.BoNotiBrokerQuitJobEvent;
import vn.com.vndirect.event.other.BoNotiBrokerQuitJobService;
import vn.com.vndirect.message.job.mail.SendEmailJob;

import java.text.SimpleDateFormat;
import java.util.*;

// Email: Thông báo Môi giới nghỉ việc

@Service
public class BoNotiBrokerQuitJobMessageJob extends SendEmailJob<BoNotiBrokerQuitJobEvent> {

    public final static Logger logger = LoggerFactory.getLogger(BoNotiBrokerQuitJobMessageJob.class);
    private final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");


    @Autowired
    public BoNotiBrokerQuitJobMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled, BoNotiBrokerQuitJobService service) {
        super(service, enabled);
    }


    @Override
    public List<EmailRequest> createMessages(BoNotiBrokerQuitJobEvent event) throws Exception {
        EmailRequest email = new EmailRequest();

//        StringBuilder subject = new StringBuilder(" Thông báo Email cho khách hàng khi MG/AE nghỉ việc; MG chuyển vị trí làm việc sang AE/SSE; AE chuyển vị trí làm việc sang SSE ");
//        email.setSubject(subject.toString());
//        email.setTemplate("");

        email.setModule("BO");
        email.setService("mail_elastic");

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(1);

        switch (event.getMgnvType()) {
            case "MGNV_KH_CHUYEN_MG_KHAC":
                email.setTemplate("email_broker_quit_job_handing_client_to_broker");
                email.setSubject("VNDIRECT thông báo thay đổi chuyên viên Môi giới quản lý tài khoản");
                fields.put("new_broker_name", event.getNewBrokerName());
                break;
            case "MGNV_KH_CHUYEN_KHDL":
                email.setTemplate("email_broker_quit_job_handing_client_to_independence");
                email.setSubject("VNDIRECT thông báo thay đổi dịch vụ quản lý tài khoản");
                break;
            case "MGNV_MG_CHUYEN_AE_KH_CHUYEN_MG_KHAC":
                email.setTemplate("email_broker_transposition_handing_client_to_brocker");
                email.setSubject("VNDIRECT thông báo thay đổi chuyên viên Môi giới quản lý tài khoản");
                break;
            case "MGNV_MG_CHUYEN_AE_KH_CHUYEN_KHDL":
                email.setTemplate("email_broker_transposition_handing_client_to_independence");
                email.setSubject("VNDIRECT thông báo thay đổi dịch vụ quản lý tài khoản");
            case "MGNV_MG_CHUYEN_AE_KH_MG_CU_AE":
                email.setTemplate("email_broker_transposition_to_ae");
                email.setSubject("VNDIRECT thông báo thay đổi dịch vụ quản lý tài khoản");
            case "MGNV_MG_CHUYEN_SSE_KH_CHUYEN_AE_KHAC":
                email.setTemplate("email_ae_transposition_to_sse");
                email.setSubject("VNDIRECT thông báo thay đổi chuyên viên chăm sóc tài khoản");
                fields.put("new_broker_name", event.getNewBrokerName());
                fields.put("phone", event.getPhoneBrokerAE());
            case "MGNV_MG_CHUYEN_SSE_KH_CHUYEN_KHDL":
                email.setTemplate("email_broker_transposition_handing_client_to_independence");
                email.setSubject("VNDIRECT thông báo thay đổi dịch vụ quản lý tài khoản");
        }

        String date = DATE_FORMAT.format(new Date());
        fields.put("customer_name", event.getFullNameCust());
        fields.put("account_no", event.getAccountNo());
        fields.put("old_broker_name", event.getOldBrokerName());
        fields.put("handing_date", date);

        email.setTempfields(fields);
        // TODO: Test
        email.setReceiver("nguyentientho110@gmail.com");
        list.add(email);

        if (!validateEmailTemplate(list)) {
            logger.error("Email Bo Noti Broker Quit Job Message: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            logger.error("Email Bo Noti Broker Quit Job Messager: No receiver or subject for email");
            return Collections.emptyList();
        }

        return list;
    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateEmailTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }
}
