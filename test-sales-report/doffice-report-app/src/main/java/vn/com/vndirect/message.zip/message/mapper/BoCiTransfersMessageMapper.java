package vn.com.vndirect.message.mapper;

import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.transaction.TransactionChanged;
import vn.com.vndirect.message.job.sms.transaction.TransactionEventToMessageJob;

import java.util.Map;

// Rút nộp đối ứng

public class BoCiTransfersMessageMapper extends TransactionToMessageMapper {
    public BoCiTransfersMessageMapper(TransactionEventToMessageJob job) {
        super(job, "1120", "1121", "1130", "1131", "1134");
    }

    @Override
    protected boolean addDataFieldFromChanged(Map<String, Object> fields, TransactionChanged changed) {
        boolean found = super.addDataFieldFromChanged(fields, changed);
        String eventType = changed.getEventType();
        if (eventType == null || eventType.length() != 1) return false;
        fields.put("event_type", eventType);
        return found;
    }

    @Override
    protected boolean isValidChanged(TransactionChanged changed) {
        if (StringUtils.isEmpty(changed.getBalance())) return false;
        return true;
    }

    @Override
    protected void setSmsMessageHeader(SMSRequest sms) {
        sms.setTemplate("sms_bo_ci_transfers");
        sms.setSubject("TRN");
        sms.setModule("BO");
    }
}
