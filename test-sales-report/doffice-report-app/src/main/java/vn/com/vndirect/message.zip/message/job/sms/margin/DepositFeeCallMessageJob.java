package vn.com.vndirect.message.job.sms.margin;

// Thông báo nợ phí lưu ký

// SMS nội dung call Xử lý : TK nợ > 500k
/*
    VNDIRECT TB: dd/mm/yyyy Phi luu ky cua TK … la …đ. Quy khach vui long thanh toan truoc 13h ngay dd/mm/yyyy. Qua thoi han tren, Cong ty se xu ly de thu no
*/
// SMS nội dung call nộp tiền: Call nộp tiền: TK nợ <= 500k
/*
    1.1.VNDIRECT TB: dd/mm/yyyy Phi luu ky cua TK … la …. Quy khach vui long thanh toan truoc ngay dd/mm/yyyy
*/

import com.homedirect.common.solr.repository.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.margin.service.BoDepositFeeCallService;
import vn.com.vndirect.event.model.margin.BoDepositFeeCallEvent;
import vn.com.vndirect.message.job.sms.SendSmsJob;

import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class DepositFeeCallMessageJob extends SendSmsJob<BoDepositFeeCallEvent> {

    public final static Logger logger = LoggerFactory.getLogger(DepositFeeCallMessageJob.class);

    private final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public DepositFeeCallMessageJob(@Value("${deposit-fee-call.message-job.enabled}") Boolean enabled,
                                    BoDepositFeeCallService service) {
        super(service, enabled);
    }

    @Override
    public List<SMSRequest> createMessages(BoDepositFeeCallEvent event) throws Exception {
        SMSRequest sms = createSmsRequest();

        sms.setSubject("FREE");
        sms.setModule("BO");
        sms.setAccountNo(event.getAccountNo());

        if (Long.parseLong(event.getMoneyAdd()) > 500000l) {
            sms.setTemplate("sms_bo_call_deposit_fee_handle");
        }

        if (Long.parseLong(event.getMoneyAdd()) <= 500000l) {
            sms.setTemplate("sms_bo_call_deposit_fee");
        }

        Map<String, Object> fields = new HashMap<>();
        List<SMSRequest> list = new ArrayList<SMSRequest>(1);

        fields.put("acct_no", event.getAccountNo());
        fields.put("prin_due", event.getMoneyAdd());
        fields.put("value_date", event.getExeDate());
        fields.put("prin_period", DATE_FORMAT.format(new Date()));
        sms.setTempFields(fields);
        list.add(sms);

        list.forEach(smsRequest -> {
            try {
                loadReceiver(smsRequest, event);
            } catch (RepositoryException e) {
                logger.error("Load receiver phone order event error for account :" + event.getAccountNo());
            }
        });

        if (!validateSmsTemplate(list)) {
            logger.error("Deposit Fee Call Message Mapper: No template or message content for sms");
            return Collections.emptyList();
        }

        if (!validateSmsReceiver(list)) {
            logger.error("Deposit Fee Call Message Mapper: No receiver or message content for sms");
            return Collections.emptyList();
        }

        return list;
    }

    protected SMSRequest createSmsRequest() {
        SMSRequest newSms = new SMSRequest();
        newSms.setBrandName("VNDS");
        newSms.setProvider("vndirect");
        newSms.setService("sms");

        return newSms;
    }

    protected void loadReceiver(SMSRequest sms, BoDepositFeeCallEvent event) throws RepositoryException {
        if (!StringUtils.isEmpty(event.getPhone())) {
            sms.setReceiverPhone(event.getPhone());
            return;
        }
        if (!StringUtils.isEmpty(event.getCustId())) {
            loadReceiverByCustomerId(sms, event.getCustId());
            return;
        }

        loadReceiverByAccountNo(sms, event.getAccountNo());
    }

    private boolean validateSmsReceiver(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getReceiverId()) && StringUtils.isEmpty(sms.getReceiverPhone())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getMessage()) && StringUtils.isEmpty(sms.getTemplate())) return false;
        }
        return true;
    }
}
