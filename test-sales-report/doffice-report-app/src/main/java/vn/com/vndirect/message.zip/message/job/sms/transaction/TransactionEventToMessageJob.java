/***************************************************************************
 * Copyright 2019 by VNDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.message.job.sms.transaction;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.homedirect.common.solr.repository.RepositoryException;

import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.transaction.TransactionChanged;
import vn.com.vndirect.event.model.transaction.TransactionEvent;
import vn.com.vndirect.event.transaction.service.TransactionEventService;
import vn.com.vndirect.message.job.sms.SendSmsJob;
import vn.com.vndirect.message.mapper.*;

@Service
public class TransactionEventToMessageJob extends SendSmsJob<TransactionEvent> {

    private final static Logger logger = LoggerFactory.getLogger(TransactionEventToMessageJob.class);

    private TransactionToMessageMapper[] mappers;

    @Autowired
    public TransactionEventToMessageJob(@Value("${event.message-job.enabled:true}") Boolean enabled,
                                        TransactionEventService service) {
        super(service, enabled);

        mappers = new TransactionToMessageMapper[]{
                new BoCashDepositMessageMapper(this),
                new BoCashWithdrawMessageMapper(this),
                new BoCompletedOutwardSETransferMessageMapper(this),
                new BoDepositCompleteMessageMapper(this),
                new BoDepositFeePaymentManualMessageMapper(this),
                new BoDividendAllocationMessageMapper(this),
                new BoMatchTradeLotRetailMessageMapper(this),
                new BoOutwardSETransferMessageMapper(this),
                new BoReceivingSETransferMessageMapper(this),
                new BoRegisterRightsMessageMapper(this),
                new BoRegisterServiceMessageMapper(this),
                new BoRevertUnregisteredRightSecurityMessageMapper(this),
                new BoTranferFromWaitingStockToTradeMessageMapper(this),
                new FdsConfirmOpeningMarginAccountMessageMapper(this),
                new FdsDepositCashFromBankMessageMapper(this),
                new FdsWithdrawCashToBankMessageMapper(this),
                new BoCiTransfersMessageMapper(this),
                new FdsOrderMachedNoDisposalMessageMapper(this),
                new FdsOrderMatchedDisposalMessageMapper(this),
                new BoDevidendCashMessageMapper(this),
                new BoCiCashWithdrawBankMessageMapper(this),
                new BoRefundMapper(this),
                new BoAllocationExerciseRightStockMessageMapper(this),
                new BoRealWithdrawalStockMessageMapper(this)
        };
    }

    @Override
    public List<SMSRequest> createMessages(TransactionEvent event) throws Exception {
        for (int i = 0; i < mappers.length; i++) {
            if (!mappers[i].isEvent(event)) continue;
            logger.info("Message Mapper: "+ mappers[i].getClass() + " : "+ event.getBody().getTransactionCode());
            List<SMSRequest> list = mappers[i].apply(event);
            
            if(!validateSmsTemplate(list)) {
                logger.error("Message Mapper: "+ mappers[i].getClass().getSimpleName() + " - No template or message content for sms");
                return Collections.emptyList();
            }
            
            if(!validateSmsReceiver(list)) {
                logger.error("Message Mapper: "+ mappers[i].getClass().getSimpleName() + " - No receiver or message content for sms");
                return Collections.emptyList();
            }
            
            return list;
        }

        return Collections.emptyList();
    }
    
    private boolean validateSmsReceiver(List<SMSRequest> list) {
        for(SMSRequest sms : list) {
            if(StringUtils.isEmpty(sms.getReceiverId()) && StringUtils.isEmpty(sms.getReceiverPhone()) ) return false;
        }
        return true;
    }
    
    private boolean validateSmsTemplate(List<SMSRequest> list) {
        for(SMSRequest sms : list) {
            if(StringUtils.isEmpty(sms.getMessage()) && StringUtils.isEmpty(sms.getTemplate()) ) return false;
        }
        return true;
    }
    
    public void loadReceiver(SMSRequest sms, TransactionChanged changed) throws RepositoryException {
        sms.setAccountNo(changed.getAccountNo());
        sms.setCustID(changed.getCustId());

        /*changed.setAccount("0001156976"); //for test
        changed.setCustid("0001105482"); //for test*/

        sms.setReceiverPhone(changed.getAccountNo());
        // TODO

        /*if(!StringUtils.isEmpty(changed.getCustid())) {
            loadReceiverByCustomerId(sms, changed.getCustid());
            return;
        }
        
        loadReceiverByAccountNo(sms, changed.getAccountNo());*/
    }


}
