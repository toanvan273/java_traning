/***************************************************************************
 * Copyright 2019 by VNDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.message.mapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.transaction.BodyEvent;
import vn.com.vndirect.event.model.transaction.TransactionChanged;
import vn.com.vndirect.event.model.transaction.TransactionEvent;
import vn.com.vndirect.message.job.sms.transaction.TransactionEventToMessageJob;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Author : Nhu Dinh Thuan
 * Email:thuan.nhu@vndirect.com.vn
 * Nov 14, 2019
 */
public abstract class TransactionToMessageMapper implements Function<TransactionEvent, List<SMSRequest>> {

    protected SimpleDateFormat timestampFormat2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
    protected SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    protected SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    protected SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

    protected NumberFormat numberFormat;

    private final static Logger logger = LoggerFactory.getLogger(TransactionToMessageMapper.class);

    private String[] transactionCodes;

    private TransactionEventToMessageJob job;

    public TransactionToMessageMapper(TransactionEventToMessageJob job, String... transactionCodes) {
        this.job = job;
        this.transactionCodes = transactionCodes;

        Locale localeEN = new Locale("en", "EN");
        numberFormat = NumberFormat.getInstance(localeEN);
    }

    public boolean isEvent(TransactionEvent event) {
        for (String code : transactionCodes) {
            if (code.equals(event.getBody().getTransactionCode())) return true;
        }
        return false;
    }

    protected abstract boolean isValidChanged(TransactionChanged changed);

    protected boolean isValidEventTypeAndBalance(TransactionChanged changed, char c) {
        if (StringUtils.isEmpty(changed.getBalance())) return false;
        return isValidEventType(changed, c);
    }

    protected boolean isValidTrade(TransactionChanged changed, char c) {
        try {
            if (Integer.parseInt(changed.getTrade()) <= 0) return false;
        } catch (Exception e) {
            logger.error(e.toString());
            return false;
        }
        return isValidEventType(changed, c);
    }

    protected boolean isValidWithdraw(TransactionChanged changed, char c) {
        try {
            if (StringUtils.isEmpty(changed.getWithdraw()) || Integer.parseInt(changed.getWithdraw()) <= 0) return false;
        } catch (Exception e) {
            logger.error(e.toString());
            return false;
        }
        return isValidEventType(changed, c);
    }

    protected boolean isValidDtoClose(TransactionChanged changed, char c) {
        try {
            if (Integer.parseInt(changed.getDtoclose()) <= 0) return false;
        } catch (Exception e) {
            logger.error(e.toString());
            return false;
        }
        return isValidEventType(changed, c);
    }

    protected boolean isValidBalanceAndSymBol(TransactionChanged changed, char c) {
        if (StringUtils.isEmpty(changed.getBalance()) && StringUtils.isEmpty(changed.getSymbol())) return false;
        return isValidEventType(changed, c);
    }

    protected boolean isValidBalance(TransactionChanged changed) {
        if (StringUtils.isEmpty(changed.getBalance()) && StringUtils.isEmpty(changed.getSymbol())) return false;
        return true;
    }

    protected boolean isValidEventType(TransactionChanged changed, char c) {
        String eventType = changed.getEventType();
        if (eventType == null || eventType.length() != 1) return false;
        return eventType.charAt(0) == c;
    }

    protected boolean hasDataField() {
        return true;
    }

    protected boolean addDataFieldFromChanged(Map<String, Object> fields, TransactionChanged changed) {
        String balance = changed.getBalance();
        String remainBalance = changed.getRemainBalance();

        try {
            String balanceFm = numberFormat.format(Double.parseDouble(balance));
            String remainBalanceFm = numberFormat.format(Double.parseDouble(remainBalance));

            fields.put("balance", balanceFm);
            fields.put("remain_balance", remainBalanceFm);

            return true;
        } catch (RuntimeException e) {
            logger.error(e.toString() + " at class " + getClass().getSimpleName());
            return false;
        }
    }

    protected boolean addDataFieldFromMultiChanged(Map<String, Object> fields, List<TransactionChanged> changed) {
        TransactionChanged changedWithBalance = changed.stream().filter(change -> !StringUtils.isEmpty(change.getBalance())).findFirst().get();
        return addDataFieldFromChanged(fields, changedWithBalance);
    }

    protected abstract void setSmsMessageHeader(SMSRequest sms);

    protected SMSRequest createSmsRequest() {
        SMSRequest newSms = new SMSRequest();
        newSms.setBrandName("VNDS");
        newSms.setProvider("vndirect");
        newSms.setService("sms");

        setSmsMessageHeader(newSms);

        return newSms;
    }

    protected void putDateTimeToField(Map<String, Object> fields, BodyEvent body) throws Exception {
        String time = body.getTimestamp();
        Date date = time.length() > 24 ? timestampFormat2.parse(time) : timestampFormat.parse(time);

        String valueDate = dateFormat.format(date);
        String valueTime = timeFormat.format(date);

        fields.put("value_date", valueDate);
        fields.put("value_time", valueTime);
    }

    public List<SMSRequest> apply(TransactionEvent event) {

        if (!hasDataField()) {
            return Arrays.asList(createSmsRequest());
        }

        BodyEvent body = event.getBody();
        TransactionChanged[] changeds = body.getChanged();

        if (changeds == null) return Collections.emptyList();

        Predicate<TransactionChanged> filter = changed -> isValidChanged(changed);

        Function<TransactionChanged, SMSRequest> oneChangedfunction = changed -> {
            SMSRequest newSms = createSmsRequest();

            Map<String, Object> fields = new HashMap<>();

            try {
                putDateTimeToField(fields, body);
            } catch (Exception e) {
                logger.error(e.toString(), e);
            }

            fields.put("account_no", changed.getAccountNo());

            try {
                job.loadReceiver(newSms, changed);
            } catch (Exception e) {
                logger.error(e.toString(), e);
                return null;
            }

            if (!addDataFieldFromChanged(fields, changed)) {
                logger.error(event.getEventId() + " - No message for sending - changed error " + changed);
                return null;
            }

            newSms.setTempFields(fields);
            return newSms;
        };

        Function<List<TransactionChanged>, SMSRequest> multiChangedFunction = changed -> {
            SMSRequest newSms = createSmsRequest();

            TransactionChanged changeHasAccountOrCustId = changed.stream()
                    .filter(change -> !(StringUtils.isEmpty(change.getAccountNo()) && StringUtils.isEmpty(change.getCustId()))).findFirst().get();

            Map<String, Object> fields = new HashMap<>();

            try {
                putDateTimeToField(fields, body);
            } catch (Exception e) {
                logger.error(e.toString(), e);
            }

            fields.put("account_no", changeHasAccountOrCustId.getAccountNo());
            try {
                job.loadReceiver(newSms, changeHasAccountOrCustId);
            } catch (Exception e) {
                logger.error(e.toString(), e);
                return null;
            }

            if (!addDataFieldFromMultiChanged(fields, changed)) {
                logger.error(event.getEventId() + " - No message for sending - changed error " + changed);
                return null;
            }
            newSms.setTempFields(fields);
            return newSms;
        };

        List<SMSRequest> listSmsRequest = Collections.emptyList();
        List<TransactionChanged> filteredChanges = Arrays.stream(changeds).filter(filter).collect(Collectors.toList());

        if (event.isMultiChangeMapperToMessage()) {
            listSmsRequest = Collections.singletonList(filteredChanges).stream().map(multiChangedFunction).collect(Collectors.toList());
        } else {
            listSmsRequest = filteredChanges.stream().map(oneChangedfunction).collect(Collectors.toList());
        }
        listSmsRequest.removeIf(item -> item == null);
        return listSmsRequest;
    }
}
