package vn.com.vndirect.message.job.mail.margin;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.margin.service.BoDepositFeeCallService;
import vn.com.vndirect.event.model.margin.BoDepositFeeCallEvent;
import vn.com.vndirect.message.job.mail.SendEmailJob;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

// Thông báo nợ phí lưu ký

// @Service
public class EmailBoDepositFeeCallMessageJob extends SendEmailJob<BoDepositFeeCallEvent> {

    public static final Logger logger = LoggerFactory.getLogger(EmailBoDepositFeeCallMessageJob.class);
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public EmailBoDepositFeeCallMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                           BoDepositFeeCallService service) {
        super(service, enabled);
    }

    @Override
    public List<EmailRequest> createMessages(BoDepositFeeCallEvent event) throws Exception {
        EmailRequest email = new EmailRequest();

        String date = DATE_FORMAT.format(new Date());
        StringBuilder subject = new StringBuilder("Thông tin Khách hàng careby có  nợ phí lưu ký mà vi phạm tỷ lệ Rtt ");
        subject.append("ngày ").append(date);
        email.setSubject(subject.toString());

        email.setModule("BO");
        email.setService("mail_elastic");

        email.setAccountNo(event.getAccountNo());

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(2);

        fields.put("full_name", event.getFullNameBroker());
        fields.put("date_due", DATE_FORMAT.format(event.getExeDate()));
        fields.put("deposit", event.getAcType());
        fields.put("acct_no", event.getAccountNo());
        fields.put("full_name_cust", event.getCustomerFullName());
        fields.put("race_margin", event.getMarginRate());
        fields.put("add_amt", formatNumber(event.getMoneyAdd()));

        EmailRequest emailBroker = createMessagesForBroker(event, email, fields);
        EmailRequest emailManager = createMessagesForManager(event, email, fields);

        list.add(emailBroker);
        list.add(emailManager);

        if (!validateEmailReceiver(list)) {
            logger.error("Email Bo Call Bo Deposit Fee Margin Message Mapper: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailTemplate(list)) {
            logger.error("Email Bo Call Deposit Fee Margin Message Mapper: No receiver or subject for email");
            return Collections.emptyList();
        }
        return list;
    }

    private EmailRequest createMessagesForBroker(BoDepositFeeCallEvent event, EmailRequest email, Map<String, Object> fields) {
        email.setTempfields(fields);

        email.setTemplate("email_bo_call_deposit_fee_brokers");
        String emailBroker = event.getUserNameBroker() + "@vndirect.com.vn";
        email.setReceiver(emailBroker);

        // TODO: fake
        email.setReceiver("ngoquangphucx5ql@gmail.com");
        return email;
    }

    private EmailRequest createMessagesForManager(BoDepositFeeCallEvent event, EmailRequest email, Map<String, Object> fields) {

        Map<String, Object> managerField = new HashMap<>(fields);
        managerField.put("manager_full_name", event.getFullNameManager());
        managerField.put("group_name", event.getGroupName());
        email.setTempfields(managerField);

        email.setTemplate("email_bo_call_deposit_fee_manager_brokers");
        String emailManager = event.getUserNameManager() + "@vndirect.com.vn";
        email.setReceiver(emailManager);

        // TODO: fake
        email.setReceiver("ngoquangphucx5ql@gmail.com");

        return email;
    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateEmailTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }

    public String formatNumber(String number) {
        Locale localeEN = new Locale("en", "EN");
        NumberFormat numberFormat = NumberFormat.getInstance(localeEN);
        String numberFM = numberFormat.format(Long.parseLong(number));
        return numberFM;
    }

}
