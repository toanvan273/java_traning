package vn.com.vndirect.message.job.mail.margin;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

import vn.com.vndirect.communication.request.EmailRequest;
import vn.com.vndirect.event.margin.service.FdsCallOverdraftService;
import vn.com.vndirect.event.model.margin.FdsMarginEvent;
import vn.com.vndirect.message.job.mail.SendEmailJob;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

// Thông báo nợ đến hạn phái sinh - Email
// @Service
public class EmailFdsCallMarginMessageJob extends SendEmailJob<FdsMarginEvent> {

    public static final Logger logger = LoggerFactory.getLogger(EmailFdsCallMarginMessageJob.class);
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public EmailFdsCallMarginMessageJob(@Value("${fds.message-job.enabled}") Boolean enabled, FdsCallOverdraftService service) {
        super(service, enabled);
    }

    @Override
    public List<EmailRequest> createMessages(FdsMarginEvent event) throws Exception {
        EmailRequest emailBroker = new EmailRequest();
        EmailRequest emailManager = new EmailRequest();

        String date = DATE_FORMAT.format(new Date());

        emailBroker.setModule("FDS");
        emailBroker.setService("mail_elastic");
        emailBroker.setAccountNo(event.getAccountNo());

        emailManager.setModule("FDS");
        emailManager.setService("mail_elastic");
        emailManager.setAccountNo(event.getAccountNo());

        Map<String, Object> fields = new HashMap<>();
        List<EmailRequest> list = new ArrayList<EmailRequest>(2);

        if (StringUtils.isEmpty(event.getCustomerFullName()) || StringUtils.isEmpty(event.getFullNameManager())
                || StringUtils.isEmpty(event.getFullNameBroker()) || StringUtils.isEmpty(event.getGroupName())) return Collections.emptyList();

        fields.put("full_name", event.getFullNameBroker());
        fields.put("value_date", date);
        fields.put("deposit", event.getDmAcctNo());
        fields.put("acct_no", event.getAccountNo());

        fields.put("full_name_cust", event.getCustomerFullName());

        fields.put("over_draft", formatNumber(event.getOverDraft()));
        fields.put("max_amt", formatNumber(event.getMaxAmt()));

        emailBroker = createMessagesForBroker(event, emailBroker, fields);
        list.add(emailBroker);

        emailManager = createMessagesForManager(event, emailManager, fields);
        list.add(emailManager);

        if (!validateEmailTemplate(list)) {
            logger.error("Email Fds Call Margin Message Mapper: No template or message content for email");
            return Collections.emptyList();
        }

        if (!validateEmailReceiver(list)) {
            logger.error("Email Fds Call Margin Message Mapper: No receiver or subject for email");
            return Collections.emptyList();
        }
        return list;
    }

    private boolean validateEmailReceiver(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getSubject())
                    && StringUtils.isEmpty(email.getReceiver())) return false;
        }
        return true;
    }

    private boolean validateEmailTemplate(List<EmailRequest> list) {
        for (EmailRequest email : list) {
            if (StringUtils.isEmpty(email.getMessage()) &&
                    StringUtils.isEmpty(email.getTemplate())) return false;
        }
        return true;
    }

    private EmailRequest createMessagesForBroker(FdsMarginEvent event, EmailRequest email, Map<String, Object> fields) {
        email.setTempfields(fields);
        email.setTemplate("email_fds_call_over_draft_brokers");

        String emailBroker = event.getUserNameBroker() + "@vndirect.com.vn";
        email.setReceiver(emailBroker);
        email.setSubject("Thông báo Call Margin giao dịch phái sinh - Môi giới");

        // TODO: fake
        email.setReceiver("ngoquangphucx5ql@gmail.com");

        return email;
    }

    private EmailRequest createMessagesForManager(FdsMarginEvent event, EmailRequest email, Map<String, Object> fields) {
        Map<String, Object> managerFields = new HashMap<>(fields);
        managerFields.put("manager_full_name", event.getFullNameManager());
        email.setTempfields(managerFields);

        email.setTemplate("email_fds_call_over_draft_manager_brokers");
        String emailManager = event.getUserNameManager() + "@vndirect.com.vn";
        email.setReceiver(emailManager);
        email.setSubject("Thông báo Call Margin giao dịch phái sinh - Trưởng phòng");

        // TODO: fake
        email.setReceiver("ngoquangphucx5ql@gmail.com");

        return email;
    }

    public String formatNumber(String number) {
        Locale localeEN = new Locale("en", "EN");
        NumberFormat numberFormat = NumberFormat.getInstance(localeEN);
        String numberFM = numberFormat.format(Long.parseLong(number));
        return numberFM;
    }

}
