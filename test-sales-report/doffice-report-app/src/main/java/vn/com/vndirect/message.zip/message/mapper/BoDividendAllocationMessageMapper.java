/***************************************************************************
 * Copyright 2019 by VNDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.message.mapper;

import java.util.Map;

import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.transaction.TransactionChanged;
import vn.com.vndirect.message.job.sms.transaction.TransactionEventToMessageJob;

// Nhận tiền cổ tức
public class BoDividendAllocationMessageMapper extends TransactionToMessageMapper {

    public BoDividendAllocationMessageMapper(TransactionEventToMessageJob job) {
        super(job, "1149");
    }

    @Override
    protected boolean addDataFieldFromChanged(Map<String, Object> fields, TransactionChanged changed) {
        boolean found = super.addDataFieldFromChanged(fields, changed);
        fields.put("symbol", changed.getSymbol());
        return found;
    }

    @Override
    protected boolean isValidChanged(TransactionChanged changed) {
        return super.isValidEventTypeAndBalance(changed, 'C');
    }

    @Override
    protected void setSmsMessageHeader(SMSRequest sms) {
        sms.setTemplate("sms_bo_dividend_allocation");
        sms.setSubject("TRN");
        sms.setModule("BO");
    }

   

}
