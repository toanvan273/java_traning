/***************************************************************************
 * Copyright 2019 by VNDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.message.mapper;

import java.util.Map;

import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.transaction.TransactionChanged;
import vn.com.vndirect.message.job.sms.transaction.TransactionEventToMessageJob;

// Hoàn tất lưu ký Sổ cổ đông

public class BoDepositCompleteMessageMapper extends TransactionToMessageMapper {

    public BoDepositCompleteMessageMapper(TransactionEventToMessageJob job) {
        super(job, "2246");
    }

    @Override
    protected boolean addDataFieldFromChanged(Map<String, Object> fields, TransactionChanged changed) {
        String trade = changed.getTrade();

        fields.put("trade", trade);
        fields.put("symbol", changed.getSymbol());
        return true;
    }

    @Override
    protected boolean isValidChanged(TransactionChanged changed) {
        return super.isValidTrade(changed, 'C');
    }

    @Override
    protected  void setSmsMessageHeader(SMSRequest sms) {
        sms.setTemplate("sms_bo_deposit_complete");
        sms.setSubject("TRN");
        sms.setModule("BO");
    }


}
