package vn.com.vndirect.message.job.sms.ccq;

import com.homedirect.common.solr.repository.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.ccq.BoSmsCCQBuyAndSellService;
import vn.com.vndirect.event.model.ccq.BoSmsCCQBuyAndSellEvent;
import vn.com.vndirect.message.job.sms.SendSmsJob;

import java.text.SimpleDateFormat;
import java.util.*;

// CCQ: SMS nhắn tin kết quả khớp lệnh Chứng Chỉ Quỹ

// @Service
public class BoSmsCCQBuyAndSellMessageJob extends SendSmsJob<BoSmsCCQBuyAndSellEvent> {

    public final static Logger logger = LoggerFactory.getLogger(BoSmsCCQBuyAndSellMessageJob.class);
    private final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    @Autowired
    public BoSmsCCQBuyAndSellMessageJob(@Value("${bo.message-job.enabled}") Boolean enabled,
                                        BoSmsCCQBuyAndSellService service) {
        super(service, enabled);
    }

    @Override
    public List<SMSRequest> createMessages(BoSmsCCQBuyAndSellEvent event) throws Exception {
        SMSRequest sms = createSmsRequest();

        sms.setSubject("FREE");
        sms.setModule("BO");

        Map<String, Object> fields = new HashMap<>();
        List<SMSRequest> list = new ArrayList<SMSRequest>(1);

        switch (event.getCcqType()) {
            case "VNDAF_SELL":
                sms.setTemplate("sms_vndaf_sell");
                fields.put("quantity_ccq", event.getQuantity());
                break;
            case "VNDAF_BUY":
                sms.setTemplate("sms_vndaf_buy");
                fields.put("amount", event.getAmountCash());
                break;
            case "VNDBF_SELL":
                sms.setTemplate("sms_vndbf_sell");
                fields.put("quantity_ccq", event.getQuantity());
                break;
            case "VNDBF_BUY":
                sms.setTemplate("sms_vndbf_buy");
                fields.put("amount", event.getAmountCash());
        }

        sms.setAccountNo(event.getAccountNo());
        sms.setCustID(event.getCustId());


        String date = DATE_FORMAT.format(new Date());

        fields.put("acct_no", event.getAccountNo());
        fields.put("value_date", date);

        sms.setTempFields(fields);
        list.add(sms);

        list.forEach(smsRequest -> {
            try {
                loadReceiver(smsRequest, event);
            } catch (RepositoryException e) {
                logger.error("Load receiver phone call VNDAF SELL event error for account :" + event.getAccountNo());
            }
        });

        if (!validateSmsTemplate(list)) {
            logger.error("VNDAF SELL Message Mapper: No template or message content for sms");
            return Collections.emptyList();
        }

        if (!validateSmsReceiver(list)) {
            logger.error("VNDAF SELL Message Mapper: No receiver or message content for sms");
            return Collections.emptyList();
        }
        return list;
    }

    protected SMSRequest createSmsRequest() {
        SMSRequest newSms = new SMSRequest();
        newSms.setBrandName("VNDS");
        newSms.setProvider("vndirect");
        newSms.setService("sms");

        return newSms;
    }

    protected void loadReceiver(SMSRequest sms, BoSmsCCQBuyAndSellEvent event) throws RepositoryException {
        if (!StringUtils.isEmpty(event.getPhone())) {
            sms.setReceiverPhone(event.getPhone());
            return;
        }
        if (!StringUtils.isEmpty(event.getCustId())) {
            loadReceiverByCustomerId(sms, event.getCustId());
            return;
        }

        loadReceiverByAccountNo(sms, event.getAccountNo());
    }

    private boolean validateSmsReceiver(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getReceiverId()) && StringUtils.isEmpty(sms.getReceiverPhone())) return false;
        }
        return true;
    }

    private boolean validateSmsTemplate(List<SMSRequest> list) {
        for (SMSRequest sms : list) {
            if (StringUtils.isEmpty(sms.getMessage()) && StringUtils.isEmpty(sms.getTemplate())) return false;
        }
        return true;
    }
}
