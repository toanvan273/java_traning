package vn.com.vndirect.message.mapper;

import vn.com.vndirect.communication.request.SMSRequest;
import vn.com.vndirect.event.model.transaction.TransactionChanged;
import vn.com.vndirect.message.job.sms.transaction.TransactionEventToMessageJob;

import java.util.Map;

// Khớp lệnh phái sinh không xử lý

public class FdsOrderMachedNoDisposalMessageMapper extends TransactionToMessageMapper {
    public FdsOrderMachedNoDisposalMessageMapper(TransactionEventToMessageJob job) {
        super(job, "DO30");
    }

    @Override
    protected boolean isValidChanged(TransactionChanged changed) {
        if (Integer.parseInt(changed.getMatchQuantity()) <= 0) return false;
        if (!"N".equals(changed.getIsDisposal())) return false;
        return true;
    }

    @Override
    protected boolean addDataFieldFromChanged(Map<String, Object> fields, TransactionChanged changed) {
        fields.put("side", changed.getSide());
        fields.put("quantity", changed.getQuantity());
        fields.put("symbol", changed.getSymbol());
        fields.put("match_quantity", changed.getMatchQuantity());

        String price = changed.getPrice();
        String matchPrice = changed.getMatchPrice();

        String priceFm = numberFormat.format(Double.parseDouble(price));
        String matchPriceFm = numberFormat.format(Double.parseDouble(matchPrice));

        fields.put("price", priceFm);
        fields.put("match_price", matchPriceFm);

        return true;
    }

    @Override
    protected void setSmsMessageHeader(SMSRequest sms) {
        sms.setTemplate("sms_fds_order_matched");
        sms.setSubject("ORD");
        sms.setModule("FDS");
    }
}
