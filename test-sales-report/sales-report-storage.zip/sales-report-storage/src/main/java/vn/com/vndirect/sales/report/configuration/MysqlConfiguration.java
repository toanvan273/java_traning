/***************************************************************************
 * Copyright by HomeDirect - All rights reserved.                *    
 **************************************************************************/
package vn.com.vndirect.sales.report.configuration;

import java.util.HashMap;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableJpaRepositories(
        entityManagerFactoryRef = "entityManagerFactory",
        transactionManagerRef = "mysqlTransactionManager",
        basePackages = {"vn.com.vndirect.vndid.storage.repository"})
public class MysqlConfiguration {

    private final Logger logger = LoggerFactory.getLogger(MysqlConfiguration.class);

    @Value("${mysql.datasource.hikari.maximumPoolSize}")
    private Integer maxPoolSize;

    @Value("${mysql.datasource.hikari.maxLifetime}")
    private Integer maxLifetime;

    @Value("${mysql.datasource.hikari.minimumIdle}")
    private Integer minimumIdle;

    @Value("${mysql.datasource.hikari.idleTimeout}")
    private Integer idleTimeout;

    @Value("${mysql.datasource.hikari.connectionTimeout}")
    private Integer connectionTimeout;

    @Value("${mysql.datasource.hikari.leakDetectionThreshold}")
    private Integer leakDetectionThreshold;

    @Value("${mysql.datasource.hikari.autoCommit}")
    private Boolean autoCommit;

    @Autowired
    public MysqlConfiguration(Environment env) {
        logger.info("Url: {}", env.getProperty("mysql.datasource.url"));
    }

    @Primary
    @Bean(name = "userMysqlDataSourceProperties")
    @ConfigurationProperties(prefix = "mysql.datasource")
    protected DataSourceProperties userMysqlDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Autowired
    @Bean(name = "mysqlDataSource")
    public DataSource mysqlDataSource(@Qualifier("userMysqlDataSourceProperties") DataSourceProperties properties) {
        HikariDataSource dataSource = (HikariDataSource) properties.initializeDataSourceBuilder().build();
        dataSource.setMaxLifetime(maxLifetime);
        dataSource.setMinimumIdle(minimumIdle);
        dataSource.setMaximumPoolSize(maxPoolSize);
        dataSource.setIdleTimeout(idleTimeout);
        dataSource.setConnectionTimeout(connectionTimeout);
        dataSource.setLeakDetectionThreshold(leakDetectionThreshold);
        dataSource.setAutoCommit(autoCommit);
        dataSource.addDataSourceProperty("cachePrepStmts", true);
        dataSource.addDataSourceProperty("prepStmtCacheSize", 250);
        dataSource.addDataSourceProperty("prepStmtCacheSqlLimit", 2048);
        dataSource.addDataSourceProperty("useServerPrepStmts", true);
        dataSource.setPoolName("HikariPool-MySQL");
        return dataSource;
    }

    @Primary
    @Autowired
    @Bean(name = "entityManagerFactory")
    public LocalContainerEntityManagerFactoryBean mysqlEntityManagerFactory(EntityManagerFactoryBuilder builder,
                                                                            @Qualifier("mysqlDataSource") DataSource mysqlDataSource) {
        return builder
                .dataSource(mysqlDataSource)
                .packages("vn.com.vndirect.vndid.common")
                .persistenceUnit("mysql")
                .build();
    }

    @Autowired
    @Bean(name = "mysqlTransactionManager")
    public PlatformTransactionManager mysqlTransactionManager(
            @Qualifier("entityManagerFactory")
                    EntityManagerFactory mysqlEntityManagerFactory) {
        return new JpaTransactionManager(mysqlEntityManagerFactory);
    }
    
    @Bean
    public EntityManagerFactoryBuilder entityManagerFactoryBuilder() {
        return new EntityManagerFactoryBuilder(new HibernateJpaVendorAdapter(), new HashMap<>(), null);
    }

}
