package vn.com.vndirect.sales.report.model;

public class HealthData {

}
